"""
seed_data.py — Populates a Hospital instance with realistic demo data so the
dashboard, charts, and tables look populated immediately (useful for
screenshots, demos, and interviews without manual data entry).
"""

import random
import datetime

import models as m

FIRST_NAMES_M = ["Rohan", "Amit", "Vikram", "Arjun", "Karan", "Aditya", "Suresh", "Manoj"]
FIRST_NAMES_F = ["Priya", "Ananya", "Neha", "Sneha", "Kavita", "Pooja", "Riya", "Divya"]
LAST_NAMES = ["Sharma", "Verma", "Gupta", "Singh", "Patel", "Mehta", "Yadav", "Kumar", "Joshi", "Reddy"]
BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
SPECIALIZATIONS = ["Cardiology", "Orthopedics", "Pediatrics", "Neurology",
                    "Dermatology", "General Medicine", "Gynecology", "ENT"]
DEPARTMENTS = ["ICU", "Emergency", "General Ward", "Pediatric Ward", "Surgery", "Maternity"]
DIAGNOSES = [
    ("Seasonal Viral Fever", "Paracetamol 650mg twice daily for 5 days", "Advised rest and hydration."),
    ("Type 2 Diabetes Follow-up", "Metformin 500mg after meals", "HbA1c stable, recheck in 3 months."),
    ("Hypertension", "Amlodipine 5mg once daily", "Monitor BP weekly."),
    ("Acute Bronchitis", "Azithromycin 500mg for 3 days", "Avoid cold exposure."),
    ("Migraine", "Sumatriptan as needed", "Triggered by stress, recommended lifestyle changes."),
]
LAB_TESTS = [
    ("Complete Blood Count", "Within normal range"),
    ("Lipid Profile", "LDL slightly elevated"),
    ("Blood Sugar (Fasting)", "98 mg/dL — Normal"),
    ("Thyroid Profile (T3/T4/TSH)", "Normal"),
    ("Liver Function Test", "Normal"),
    ("X-Ray Chest", "No abnormality detected"),
]
MEDICINE_CATALOG = [
    ("Paracetamol 650mg", 2.5), ("Amoxicillin 500mg", 6.0), ("Cetirizine 10mg", 1.8),
    ("Metformin 500mg", 3.2), ("Amlodipine 5mg", 4.0), ("Azithromycin 500mg", 12.0),
    ("Omeprazole 20mg", 5.5), ("Ibuprofen 400mg", 2.0), ("ORS Sachet", 8.0),
    ("Insulin Glargine", 320.0), ("Atorvastatin 10mg", 7.5), ("Vitamin D3 Sachet", 15.0),
]


def _rand_date(days_back=0, days_forward=0):
    delta = random.randint(-days_back, days_forward)
    return (datetime.date.today() + datetime.timedelta(days=delta)).strftime("%Y-%m-%d")


def seed(hospital: m.Hospital, n_patients=14, n_doctors=6, n_nurses=8, seed_value=42):
    """Populate `hospital` in place with demo records. Idempotent per call (fresh state expected)."""
    random.seed(seed_value)

    # ── Doctors ──
    for i in range(n_doctors):
        gender = random.choice(["Male", "Female"])
        first = random.choice(FIRST_NAMES_M if gender == "Male" else FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)
        hospital.add_doctor(
            name=f"{first} {last}",
            age=random.randint(30, 60),
            gender=gender,
            phone=f"9{random.randint(100000000, 999999999)}",
            specialization=random.choice(SPECIALIZATIONS),
            consultation_fee=random.choice([300, 400, 500, 600, 800, 1000]),
        )

    # ── Nurses ──
    for i in range(n_nurses):
        gender = random.choice(["Male", "Female"])
        first = random.choice(FIRST_NAMES_M if gender == "Male" else FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)
        hospital.add_nurse(
            name=f"{first} {last}",
            age=random.randint(22, 45),
            gender=gender,
            phone=f"9{random.randint(100000000, 999999999)}",
            department=random.choice(DEPARTMENTS),
            shift=random.choice(list(m.Nurse.VALID_SHIFTS)),
        )

    # ── Medicines ──
    for name, price in MEDICINE_CATALOG:
        stock = random.randint(5, 400)
        # a couple of items deliberately low-stock or near-expiry for realism
        expiry_days = random.choice([random.randint(-10, 20), random.randint(60, 720)])
        expiry = (datetime.date.today() + datetime.timedelta(days=expiry_days)).strftime("%Y-%m-%d")
        hospital.add_medicine(name, stock, price, expiry)

    # ── Patients ──
    patient_ids = []
    for i in range(n_patients):
        gender = random.choice(["Male", "Female"])
        first = random.choice(FIRST_NAMES_M if gender == "Male" else FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)
        p = hospital.register_patient(
            name=f"{first} {last}",
            age=random.randint(4, 78),
            gender=gender,
            phone=f"9{random.randint(100000000, 999999999)}",
            blood_group=random.choice(BLOOD_GROUPS),
        )
        patient_ids.append(p.patient_id)

    doctor_ids = list(hospital.doctors.keys())

    # ── Appointments (mix of past/future, varied statuses) ──
    for i in range(22):
        pid = random.choice(patient_ids)
        did = random.choice(doctor_ids)
        slot = random.choice(hospital.doctors[did].available_slots)
        date = _rand_date(days_back=20, days_forward=14)
        try:
            appt = hospital.book_appointment(pid, did, date, slot)
            roll = random.random()
            if roll < 0.35:
                appt.status = "Completed"
            elif roll < 0.45:
                appt.cancel()
            elif roll < 0.55:
                pass  # leave Scheduled
        except Exception:
            continue  # skip slot conflicts silently, demo data doesn't need to be perfect

    # ── Medical records ──
    for i in range(16):
        pid = random.choice(patient_ids)
        diagnosis, prescription, notes = random.choice(DIAGNOSES)
        try:
            hospital.add_medical_record(pid, diagnosis, prescription, notes)
        except Exception:
            continue

    # ── Lab reports ──
    for i in range(13):
        pid = random.choice(patient_ids)
        test, result = random.choice(LAB_TESTS)
        try:
            hospital.generate_lab_report(pid, test, result)
        except Exception:
            continue

    # ── Bills ──
    for i in range(18):
        pid = random.choice(patient_ids)
        try:
            hospital.generate_bill(
                pid,
                consultation_charge=random.choice([0, 300, 400, 500, 600]),
                medicine_charge=round(random.uniform(0, 600), 2),
                lab_charge=random.choice([0, 0, 250, 450, 800]),
            )
        except Exception:
            continue

    return hospital
