# ============================================================
#
#   SMART HOSPITAL MANAGEMENT SYSTEM
#   Developed using Python & Object-Oriented Programming
#
#   Concepts Covered:
#     - Abstract Classes, Inheritance, Polymorphism
#     - Encapsulation, Composition
#     - Static Methods, Class Methods, Magic Methods
#     - Decorators, Generators, Lambda Functions
#     - Recursion, List Comprehension
#     - JSON File Handling, CSV Report Generation
#     - Exception Handling, DateTime Module
#     - Menu-Driven Interface
#     - Data Structures: List, Dict, Set, Tuple
#
# ============================================================

import os
import json
import csv
import functools
import datetime
from abc import ABC, abstractmethod


# ============================================================
#  SECTION 1: CUSTOM EXCEPTIONS
# ============================================================

class InvalidPatientIDError(Exception):
    """Raised when a patient ID is not found in the system."""
    def __init__(self, patient_id):
        self.patient_id = patient_id
        super().__init__(f"[ERROR] Patient ID '{patient_id}' not found in the system.")


class InvalidDoctorIDError(Exception):
    """Raised when a doctor ID is not found in the system."""
    def __init__(self, doctor_id):
        self.doctor_id = doctor_id
        super().__init__(f"[ERROR] Doctor ID '{doctor_id}' not found in the system.")


class InvalidNurseIDError(Exception):
    """Raised when a nurse ID is not found in the system."""
    def __init__(self, nurse_id):
        self.nurse_id = nurse_id
        super().__init__(f"[ERROR] Nurse ID '{nurse_id}' not found in the system.")


class AppointmentConflictError(Exception):
    """Raised when a doctor already has an appointment at the requested slot."""
    def __init__(self, doctor_id, date, slot):
        super().__init__(
            f"[ERROR] Appointment conflict: Doctor '{doctor_id}' is already booked "
            f"on {date} at {slot}."
        )


class InsufficientStockError(Exception):
    """Raised when medicine stock is less than the requested quantity."""
    def __init__(self, medicine_name, available, requested):
        super().__init__(
            f"[ERROR] Insufficient stock for '{medicine_name}'. "
            f"Available: {available}, Requested: {requested}."
        )


class InvalidBillAmountError(Exception):
    """Raised when a bill amount is zero, negative, or otherwise invalid."""
    def __init__(self, amount):
        super().__init__(f"[ERROR] Invalid bill amount: {amount}. Amount must be positive.")


class MissingFileError(Exception):
    """Raised when a required JSON data file is not found."""
    def __init__(self, filename):
        self.filename = filename
        super().__init__(f"[ERROR] Data file '{filename}' not found. Starting with empty data.")


class InvalidInputError(Exception):
    """Raised when user provides empty, wrong type, or out-of-range input."""
    def __init__(self, field, reason="Invalid value provided"):
        self.field = field
        super().__init__(f"[ERROR] Invalid input for '{field}': {reason}.")


class MedicineExpiredError(Exception):
    """Raised when a medicine has passed its expiry date."""
    def __init__(self, medicine_name, expiry_date):
        super().__init__(
            f"[ERROR] Medicine '{medicine_name}' expired on {expiry_date}. Cannot be dispensed."
        )


class SlotNotAvailableError(Exception):
    """Raised when a doctor does not have the requested slot available."""
    def __init__(self, doctor_id, slot):
        super().__init__(
            f"[ERROR] Slot '{slot}' is not in Doctor '{doctor_id}'s available slots."
        )


# ============================================================
#  SECTION 2: UTILITY FUNCTIONS, DECORATORS, GENERATORS
# ============================================================

# ── DateTime Utilities ────────────────────────────────────

def get_current_date():
    """Return today's date as YYYY-MM-DD string."""
    return datetime.date.today().strftime("%Y-%m-%d")


def get_current_datetime():
    """Return current date and time as a formatted string."""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def is_valid_date(date_str):
    """Validate that a string is a real date in YYYY-MM-DD format."""
    try:
        datetime.datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def is_date_in_future(date_str):
    """Return True if the given date string is today or in the future."""
    try:
        given = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
        return given >= datetime.date.today()
    except ValueError:
        return False


def is_expired(expiry_date_str):
    """Return True if expiry_date_str is before today."""
    try:
        expiry = datetime.datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
        return expiry < datetime.date.today()
    except ValueError:
        return False


# ── ID Generators (User-Defined Functions) ────────────────

def generate_patient_id(existing_ids):
    """Generate next patient ID like P001, P002, ..."""
    count = len(existing_ids) + 1
    return f"P{count:03d}"


def generate_doctor_id(existing_ids):
    """Generate next doctor ID like D001, D002, ..."""
    count = len(existing_ids) + 1
    return f"D{count:03d}"


def generate_nurse_id(existing_ids):
    """Generate next nurse ID like N001, N002, ..."""
    count = len(existing_ids) + 1
    return f"N{count:03d}"


def generate_appointment_id(existing_list):
    """Generate next appointment ID like A001, A002, ..."""
    count = len(existing_list) + 1
    return f"A{count:03d}"


def generate_bill_id(existing_list):
    """Generate next bill ID like B001, B002, ..."""
    count = len(existing_list) + 1
    return f"B{count:03d}"


def generate_medicine_id(existing_ids):
    """Generate next medicine ID like M001, M002, ..."""
    count = len(existing_ids) + 1
    return f"M{count:03d}"


def generate_record_id(existing_list):
    """Generate next medical record ID like R001, R002, ..."""
    count = len(existing_list) + 1
    return f"R{count:03d}"


def generate_report_id(existing_list):
    """Generate next lab report ID like LR001, LR002, ..."""
    count = len(existing_list) + 1
    return f"LR{count:03d}"


# ── Lambda Functions (PDF requirement) ───────────────────

# Sort a list of Doctor objects by consultation_fee (ascending)
sort_doctors_by_fee = lambda doctors: sorted(
    doctors, key=lambda d: d.consultation_fee
)

# Sort a list of Medicine objects by price (ascending)
sort_medicines_by_price = lambda medicines: sorted(
    medicines, key=lambda m: m.price
)

# Sort a list of Appointment objects by appointment_date (ascending)
sort_appointments_by_date = lambda appointments: sorted(
    appointments, key=lambda a: a.appointment_date
)


# ── Decorators (PDF requirement) ─────────────────────────

ACTIVITY_LOG = []   # in-memory feed consumed by the GUI's "Recent Activity" panel
MAX_LOG_ENTRIES = 200


def log_action(action_name):
    """
    Decorator factory that logs the action name, timestamp,
    and success/failure status. Also pushes a structured entry
    onto ACTIVITY_LOG so the GUI can render a live activity feed.
    Decorates: register_patient, book_appointment, generate_bill
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            timestamp = get_current_datetime()
            try:
                result = func(*args, **kwargs)
                ACTIVITY_LOG.append({
                    "action": action_name,
                    "time": timestamp,
                    "status": "SUCCESS",
                    "detail": str(result) if result is not None else "",
                })
                del ACTIVITY_LOG[:-MAX_LOG_ENTRIES]
                return result
            except Exception as e:
                ACTIVITY_LOG.append({
                    "action": action_name,
                    "time": timestamp,
                    "status": "FAILED",
                    "detail": str(e),
                })
                del ACTIVITY_LOG[:-MAX_LOG_ENTRIES]
                raise
        return wrapper
    return decorator


# ── Generators (PDF requirement) ─────────────────────────

def appointment_report_generator(appointments):
    """
    Generator: yields one appointment dict at a time.
    Used for writing CSV reports without loading all records into memory.
    """
    for appt in appointments:
        yield {
            "Appointment ID": appt.appointment_id,
            "Patient ID":     appt.patient_id,
            "Doctor ID":      appt.doctor_id,
            "Date":           appt.appointment_date,
            "Slot":           appt.slot,
            "Status":         appt.status,
        }


def billing_report_generator(bills):
    """
    Generator: yields one bill dict at a time.
    Used for writing CSV billing reports.
    """
    for bill in bills:
        yield {
            "Bill ID":              bill.bill_id,
            "Patient ID":           bill.patient_id,
            "Consultation Charge":  bill.consultation_charge,
            "Medicine Charge":      bill.medicine_charge,
            "Lab Charge":           bill.lab_charge,
            "Total Amount":         bill.total_amount,
            "Generated On":         bill.generated_on,
        }


def lab_report_generator(lab_reports):
    """
    Generator: yields one lab report dict at a time.
    Used for generating lab CSV exports.
    """
    for report in lab_reports:
        yield {
            "Report ID":   report.report_id,
            "Patient ID":  report.patient_id,
            "Test Name":   report.test_name,
            "Result":      report.result,
            "Report Date": report.report_date,
        }


# ============================================================
#  SECTION 3: ABSTRACT BASE CLASS — Person
# ============================================================

class Person(ABC):
    """
    Abstract base class for all people in the hospital system.
    Cannot be instantiated directly.

    OOP Concepts: Abstraction, Encapsulation, Inheritance root
    """

    def __init__(self, person_id, name, age, gender, phone):
        # Encapsulation: private attributes with name-mangling
        self.__person_id = person_id
        self.__name      = name
        self.__age       = age
        self.__gender    = gender
        self.__phone     = phone

    # ── Getters ──────────────────────────────
    @property
    def person_id(self):
        return self.__person_id

    @property
    def name(self):
        return self.__name

    @property
    def age(self):
        return self.__age

    @property
    def gender(self):
        return self.__gender

    @property
    def phone(self):
        return self.__phone

    # ── Setters ──────────────────────────────
    @name.setter
    def name(self, value):
        if value.strip():
            self.__name = value.strip()

    @age.setter
    def age(self, value):
        if isinstance(value, int) and 0 < value < 150:
            self.__age = value

    @phone.setter
    def phone(self, value):
        if value.strip():
            self.__phone = value.strip()

    # ── Abstract Method (Polymorphism) ────────
    @abstractmethod
    def display_details(self):
        """Each subclass must implement its own display_details()."""
        pass

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return f"{self.__class__.__name__}[{self.__person_id}] - {self.__name}"

    def __repr__(self):
        return (f"{self.__class__.__name__}(id={self.__person_id!r}, "
                f"name={self.__name!r}, age={self.__age}, "
                f"gender={self.__gender!r}, phone={self.__phone!r})")

    # ── Static Method ─────────────────────────
    @staticmethod
    def generate_id(prefix, existing_count):
        """
        Static Method: Generate a unique ID.
        E.g., generate_id('P', 3) → 'P004'
        """
        return f"{prefix}{existing_count + 1:03d}"


# ============================================================
#  SECTION 4: PATIENT CLASS (inherits Person)
# ============================================================

class Patient(Person):
    """
    Represents a hospital patient.
    Inherits from Person.

    OOP: Inheritance, Polymorphism (display_details overridden)
    Data Structures: list (medical_history, appointments)
    """

    def __init__(self, patient_id, name, age, gender, phone, blood_group):
        super().__init__(patient_id, name, age, gender, phone)
        self.__patient_id      = patient_id
        self.__blood_group     = blood_group
        self.__medical_history = []   # List — PDF requirement
        self.__appointments    = []   # List — PDF requirement

    # ── Properties ───────────────────────────
    @property
    def patient_id(self):
        return self.__patient_id

    @property
    def blood_group(self):
        return self.__blood_group

    @property
    def medical_history(self):
        return list(self.__medical_history)

    @property
    def appointments(self):
        return list(self.__appointments)

    @blood_group.setter
    def blood_group(self, value):
        valid = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
        if value.upper() in valid:
            self.__blood_group = value.upper()

    # ── Methods (from PDF) ────────────────────
    def book_appointment(self, appointment_id):
        """Add an appointment ID to the patient's appointment list."""
        if appointment_id not in self.__appointments:
            self.__appointments.append(appointment_id)

    def add_medical_history(self, record_id):
        """Append a medical record ID to patient's history."""
        if record_id not in self.__medical_history:
            self.__medical_history.append(record_id)

    def view_records(self):
        """Display summary of patient's record IDs."""
        print(f"\n  Medical History for {self.name} ({self.__patient_id}):")
        if self.__medical_history:
            for idx, rec in enumerate(self.__medical_history, 1):
                print(f"    {idx}. {rec}")
        else:
            print("    No medical records found.")

    # ── Polymorphism: override display_details ─
    def display_details(self):
        """Polymorphic implementation of display_details for Patient."""
        print(f"\n  ── Patient Details ──────────────────────")
        print(f"  Patient ID   : {self.__patient_id}")
        print(f"  Name         : {self.name}")
        print(f"  Age          : {self.age}")
        print(f"  Gender       : {self.gender}")
        print(f"  Phone        : {self.phone}")
        print(f"  Blood Group  : {self.__blood_group}")
        print(f"  Appointments : {self.__appointments if self.__appointments else 'None'}")
        print(f"  Med. History : {self.__medical_history if self.__medical_history else 'None'}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return f"Patient[{self.__patient_id}] - {self.name} | Blood: {self.__blood_group}"

    def __repr__(self):
        return (f"Patient(id={self.__patient_id!r}, name={self.name!r}, "
                f"age={self.age}, blood_group={self.__blood_group!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "patient_id":      self.__patient_id,
            "name":            self.name,
            "age":             self.age,
            "gender":          self.gender,
            "phone":           self.phone,
            "blood_group":     self.__blood_group,
            "medical_history": self.__medical_history,
            "appointments":    self.__appointments,
        }

    @classmethod
    def from_dict(cls, data):
        """Create a Patient object from a dictionary (JSON load)."""
        p = cls(
            patient_id  = data["patient_id"],
            name        = data["name"],
            age         = data["age"],
            gender      = data["gender"],
            phone       = data["phone"],
            blood_group = data["blood_group"],
        )
        p._Patient__medical_history = data.get("medical_history", [])
        p._Patient__appointments    = data.get("appointments", [])
        return p


# ============================================================
#  SECTION 5: DOCTOR CLASS (inherits Person)
# ============================================================

class Doctor(Person):
    """
    Represents a hospital doctor.
    Inherits from Person.

    Data Structures: tuple (available_slots — PDF requirement)
    """

    # Class-level default slots (Tuple — PDF requirement)
    DEFAULT_SLOTS = ("09:00", "10:00", "11:00", "12:00",
                     "14:00", "15:00", "16:00", "17:00")

    def __init__(self, doctor_id, name, age, gender, phone,
                 specialization, consultation_fee, available_slots=None):
        super().__init__(doctor_id, name, age, gender, phone)
        self.__doctor_id        = doctor_id
        self.__specialization   = specialization
        self.__consultation_fee = float(consultation_fee)
        if available_slots is None:
            self.__available_slots = list(Doctor.DEFAULT_SLOTS)
        else:
            self.__available_slots = list(available_slots)

    # ── Properties ───────────────────────────
    @property
    def doctor_id(self):
        return self.__doctor_id

    @property
    def specialization(self):
        return self.__specialization

    @property
    def consultation_fee(self):
        return self.__consultation_fee

    @property
    def available_slots(self):
        return tuple(self.__available_slots)   # Tuple — PDF requirement

    @specialization.setter
    def specialization(self, value):
        if value.strip():
            self.__specialization = value.strip()

    @consultation_fee.setter
    def consultation_fee(self, value):
        if isinstance(value, (int, float)) and value > 0:
            self.__consultation_fee = float(value)

    # ── Methods (from PDF) ────────────────────
    def add_slot(self, slot):
        """Add a new time slot to doctor's schedule."""
        if slot not in self.__available_slots:
            self.__available_slots.append(slot)
            print(f"  [+] Slot {slot} added for Dr. {self.name}.")
        else:
            print(f"  [!] Slot {slot} already exists.")

    def remove_slot(self, slot):
        """Remove a time slot from doctor's schedule."""
        if slot in self.__available_slots:
            self.__available_slots.remove(slot)
            print(f"  [-] Slot {slot} removed for Dr. {self.name}.")
        else:
            print(f"  [!] Slot {slot} not found in schedule.")

    def view_schedule(self):
        """Display all available slots for this doctor."""
        print(f"\n  Schedule for Dr. {self.name} ({self.__doctor_id}):")
        slots = tuple(self.__available_slots)
        if slots:
            for i, slot in enumerate(slots, 1):
                print(f"    {i}. {slot}")
        else:
            print("    No available slots.")

    # ── Polymorphism ──────────────────────────
    def display_details(self):
        """Polymorphic implementation of display_details for Doctor."""
        print(f"\n  ── Doctor Details ───────────────────────")
        print(f"  Doctor ID       : {self.__doctor_id}")
        print(f"  Name            : {self.name}")
        print(f"  Age             : {self.age}")
        print(f"  Gender          : {self.gender}")
        print(f"  Phone           : {self.phone}")
        print(f"  Specialization  : {self.__specialization}")
        print(f"  Consultation Fee: Rs. {self.__consultation_fee:.2f}")
        print(f"  Available Slots : {tuple(self.__available_slots)}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"Doctor[{self.__doctor_id}] - Dr. {self.name} "
                f"| {self.__specialization} | Fee: Rs.{self.__consultation_fee:.0f}")

    def __repr__(self):
        return (f"Doctor(id={self.__doctor_id!r}, name={self.name!r}, "
                f"specialization={self.__specialization!r}, "
                f"fee={self.__consultation_fee})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "doctor_id":        self.__doctor_id,
            "name":             self.name,
            "age":              self.age,
            "gender":           self.gender,
            "phone":            self.phone,
            "specialization":   self.__specialization,
            "consultation_fee": self.__consultation_fee,
            "available_slots":  list(self.__available_slots),
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            doctor_id        = data["doctor_id"],
            name             = data["name"],
            age              = data["age"],
            gender           = data["gender"],
            phone            = data["phone"],
            specialization   = data["specialization"],
            consultation_fee = data["consultation_fee"],
            available_slots  = data.get("available_slots", list(Doctor.DEFAULT_SLOTS)),
        )


# ============================================================
#  SECTION 6: NURSE CLASS (inherits Person)
# ============================================================

class Nurse(Person):
    """
    Represents a hospital nurse.
    Inherits from Person.
    """

    VALID_SHIFTS = ("Morning", "Evening", "Night")

    def __init__(self, nurse_id, name, age, gender, phone, department, shift):
        super().__init__(nurse_id, name, age, gender, phone)
        self.__nurse_id   = nurse_id
        self.__department = department
        self.__shift      = shift

    # ── Properties ───────────────────────────
    @property
    def nurse_id(self):
        return self.__nurse_id

    @property
    def department(self):
        return self.__department

    @property
    def shift(self):
        return self.__shift

    @department.setter
    def department(self, value):
        if value.strip():
            self.__department = value.strip()

    @shift.setter
    def shift(self, value):
        if value in Nurse.VALID_SHIFTS:
            self.__shift = value

    # ── Methods (from PDF) ────────────────────
    def assign_patient(self, patient_id):
        """Assign a patient to this nurse's care."""
        print(f"  [+] Nurse {self.name} ({self.__nurse_id}) assigned to Patient {patient_id}.")

    def update_shift(self, new_shift):
        """Update the nurse's shift."""
        if new_shift in Nurse.VALID_SHIFTS:
            old_shift = self.__shift
            self.__shift = new_shift
            print(f"  [+] {self.name}'s shift updated: {old_shift} → {new_shift}")
        else:
            print(f"  [!] Invalid shift '{new_shift}'. Valid options: {Nurse.VALID_SHIFTS}")

    # ── Polymorphism ──────────────────────────
    def display_details(self):
        """Polymorphic implementation of display_details for Nurse."""
        print(f"\n  ── Nurse Details ────────────────────────")
        print(f"  Nurse ID    : {self.__nurse_id}")
        print(f"  Name        : {self.name}")
        print(f"  Age         : {self.age}")
        print(f"  Gender      : {self.gender}")
        print(f"  Phone       : {self.phone}")
        print(f"  Department  : {self.__department}")
        print(f"  Shift       : {self.__shift}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"Nurse[{self.__nurse_id}] - {self.name} "
                f"| Dept: {self.__department} | Shift: {self.__shift}")

    def __repr__(self):
        return (f"Nurse(id={self.__nurse_id!r}, name={self.name!r}, "
                f"department={self.__department!r}, shift={self.__shift!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "nurse_id":   self.__nurse_id,
            "name":       self.name,
            "age":        self.age,
            "gender":     self.gender,
            "phone":      self.phone,
            "department": self.__department,
            "shift":      self.__shift,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            nurse_id   = data["nurse_id"],
            name       = data["name"],
            age        = data["age"],
            gender     = data["gender"],
            phone      = data["phone"],
            department = data["department"],
            shift      = data["shift"],
        )


# ============================================================
#  SECTION 7: APPOINTMENT CLASS
# ============================================================

class Appointment:
    """
    Represents a scheduled appointment between a patient and a doctor.

    Attributes from PDF:
      appointment_id, patient_id, doctor_id,
      appointment_date, status
    """

    VALID_STATUSES = ("Scheduled", "Cancelled", "Completed", "Rescheduled")

    def __init__(self, appointment_id, patient_id, doctor_id,
                 appointment_date, slot, status="Scheduled"):
        self.__appointment_id   = appointment_id
        self.__patient_id       = patient_id
        self.__doctor_id        = doctor_id
        self.__appointment_date = appointment_date
        self.__slot             = slot
        self.__status           = status

    # ── Properties ───────────────────────────
    @property
    def appointment_id(self):
        return self.__appointment_id

    @property
    def patient_id(self):
        return self.__patient_id

    @property
    def doctor_id(self):
        return self.__doctor_id

    @property
    def appointment_date(self):
        return self.__appointment_date

    @property
    def slot(self):
        return self.__slot

    @property
    def status(self):
        return self.__status

    @appointment_date.setter
    def appointment_date(self, value):
        self.__appointment_date = value

    @slot.setter
    def slot(self, value):
        self.__slot = value

    @status.setter
    def status(self, value):
        if value in Appointment.VALID_STATUSES:
            self.__status = value

    # ── Methods (from PDF) ────────────────────
    def book(self):
        """Mark appointment as Scheduled."""
        self.__status = "Scheduled"
        print(f"  [+] Appointment {self.__appointment_id} booked successfully.")
        print(f"      Patient: {self.__patient_id} | Doctor: {self.__doctor_id}")
        print(f"      Date: {self.__appointment_date} at {self.__slot}")

    def cancel(self):
        """Cancel this appointment."""
        if self.__status == "Cancelled":
            print(f"  [!] Appointment {self.__appointment_id} is already cancelled.")
        else:
            self.__status = "Cancelled"
            print(f"  [-] Appointment {self.__appointment_id} has been cancelled.")

    def reschedule(self, new_date, new_slot):
        """Reschedule to a new date and slot."""
        if self.__status == "Cancelled":
            print(f"  [!] Cannot reschedule a cancelled appointment.")
        else:
            old_date = self.__appointment_date
            old_slot = self.__slot
            self.__appointment_date = new_date
            self.__slot             = new_slot
            self.__status           = "Rescheduled"
            print(f"  [~] Appointment {self.__appointment_id} rescheduled.")
            print(f"      From: {old_date} {old_slot}  →  To: {new_date} {new_slot}")

    def display(self):
        """Print appointment summary."""
        print(f"\n  ── Appointment ──────────────────────────")
        print(f"  Appt ID  : {self.__appointment_id}")
        print(f"  Patient  : {self.__patient_id}")
        print(f"  Doctor   : {self.__doctor_id}")
        print(f"  Date     : {self.__appointment_date}")
        print(f"  Slot     : {self.__slot}")
        print(f"  Status   : {self.__status}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"Appt[{self.__appointment_id}] "
                f"P:{self.__patient_id} → D:{self.__doctor_id} "
                f"| {self.__appointment_date} {self.__slot} | {self.__status}")

    def __repr__(self):
        return (f"Appointment(id={self.__appointment_id!r}, "
                f"patient={self.__patient_id!r}, doctor={self.__doctor_id!r}, "
                f"date={self.__appointment_date!r}, slot={self.__slot!r}, "
                f"status={self.__status!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "appointment_id":   self.__appointment_id,
            "patient_id":       self.__patient_id,
            "doctor_id":        self.__doctor_id,
            "appointment_date": self.__appointment_date,
            "slot":             self.__slot,
            "status":           self.__status,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            appointment_id   = data["appointment_id"],
            patient_id       = data["patient_id"],
            doctor_id        = data["doctor_id"],
            appointment_date = data["appointment_date"],
            slot             = data["slot"],
            status           = data.get("status", "Scheduled"),
        )


# ============================================================
#  SECTION 8: MEDICINE CLASS
# ============================================================

class Medicine:
    """
    Represents a medicine in the pharmacy inventory.

    Attributes from PDF:
      medicine_id, medicine_name, stock, price, expiry_date
    """

    def __init__(self, medicine_id, medicine_name, stock, price, expiry_date):
        self.__medicine_id   = medicine_id
        self.__medicine_name = medicine_name
        self.__stock         = int(stock)
        self.__price         = float(price)
        self.__expiry_date   = expiry_date

    # ── Properties ───────────────────────────
    @property
    def medicine_id(self):
        return self.__medicine_id

    @property
    def medicine_name(self):
        return self.__medicine_name

    @property
    def stock(self):
        return self.__stock

    @property
    def price(self):
        return self.__price

    @property
    def expiry_date(self):
        return self.__expiry_date

    @medicine_name.setter
    def medicine_name(self, value):
        if value.strip():
            self.__medicine_name = value.strip()

    @price.setter
    def price(self, value):
        if isinstance(value, (int, float)) and value > 0:
            self.__price = float(value)

    # ── Methods (from PDF) ────────────────────
    def add_stock(self, quantity):
        """Increase stock by given quantity."""
        if quantity > 0:
            self.__stock += quantity
            print(f"  [+] Added {quantity} units to '{self.__medicine_name}'. "
                  f"New stock: {self.__stock}")
        else:
            print("  [!] Quantity must be positive.")

    def reduce_stock(self, quantity):
        """
        Reduce stock by given quantity.
        Raises InsufficientStockError or MedicineExpiredError as needed.
        """
        self.check_expiry()
        if quantity > self.__stock:
            raise InsufficientStockError(self.__medicine_name, self.__stock, quantity)
        self.__stock -= quantity
        print(f"  [-] Dispensed {quantity} units of '{self.__medicine_name}'. "
              f"Remaining: {self.__stock}")

    def check_expiry(self):
        """Check if this medicine has expired. Raises MedicineExpiredError if so."""
        if is_expired(self.__expiry_date):
            raise MedicineExpiredError(self.__medicine_name, self.__expiry_date)

    def display(self):
        """Print medicine details."""
        expired_tag = " [EXPIRED]" if is_expired(self.__expiry_date) else ""
        print(f"\n  ── Medicine ─────────────────────────────")
        print(f"  Medicine ID  : {self.__medicine_id}")
        print(f"  Name         : {self.__medicine_name}{expired_tag}")
        print(f"  Stock        : {self.__stock} units")
        print(f"  Price        : Rs. {self.__price:.2f} per unit")
        print(f"  Expiry Date  : {self.__expiry_date}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"Medicine[{self.__medicine_id}] - {self.__medicine_name} "
                f"| Stock: {self.__stock} | Rs.{self.__price:.2f} | Exp: {self.__expiry_date}")

    def __repr__(self):
        return (f"Medicine(id={self.__medicine_id!r}, "
                f"name={self.__medicine_name!r}, stock={self.__stock}, "
                f"price={self.__price}, expiry={self.__expiry_date!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "medicine_id":   self.__medicine_id,
            "medicine_name": self.__medicine_name,
            "stock":         self.__stock,
            "price":         self.__price,
            "expiry_date":   self.__expiry_date,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            medicine_id   = data["medicine_id"],
            medicine_name = data["medicine_name"],
            stock         = data["stock"],
            price         = data["price"],
            expiry_date   = data["expiry_date"],
        )


# ============================================================
#  SECTION 9: MEDICAL RECORD CLASS
# ============================================================

class MedicalRecord:
    """
    Stores a patient's diagnosis, prescription, and treatment notes.

    Attributes from PDF:
      record_id, patient_id, diagnosis, prescription, notes
    """

    def __init__(self, record_id, patient_id, diagnosis,
                 prescription, notes, record_date=None):
        self.__record_id    = record_id
        self.__patient_id   = patient_id
        self.__diagnosis    = diagnosis
        self.__prescription = prescription
        self.__notes        = notes
        self.__record_date  = record_date if record_date else get_current_date()

    # ── Properties ───────────────────────────
    @property
    def record_id(self):
        return self.__record_id

    @property
    def patient_id(self):
        return self.__patient_id

    @property
    def diagnosis(self):
        return self.__diagnosis

    @property
    def prescription(self):
        return self.__prescription

    @property
    def notes(self):
        return self.__notes

    @property
    def record_date(self):
        return self.__record_date

    # ── Methods (from PDF) ────────────────────
    def add_record(self):
        """Confirm record has been added."""
        print(f"  [+] Medical record {self.__record_id} added for Patient {self.__patient_id}.")

    def view_record(self):
        """Display full medical record."""
        print(f"\n  ── Medical Record ───────────────────────")
        print(f"  Record ID    : {self.__record_id}")
        print(f"  Patient ID   : {self.__patient_id}")
        print(f"  Date         : {self.__record_date}")
        print(f"  Diagnosis    : {self.__diagnosis}")
        print(f"  Prescription : {self.__prescription}")
        print(f"  Notes        : {self.__notes}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"MedRecord[{self.__record_id}] "
                f"Patient:{self.__patient_id} | {self.__record_date} "
                f"| {self.__diagnosis}")

    def __repr__(self):
        return (f"MedicalRecord(id={self.__record_id!r}, "
                f"patient={self.__patient_id!r}, "
                f"diagnosis={self.__diagnosis!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "record_id":    self.__record_id,
            "patient_id":   self.__patient_id,
            "diagnosis":    self.__diagnosis,
            "prescription": self.__prescription,
            "notes":        self.__notes,
            "record_date":  self.__record_date,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            record_id    = data["record_id"],
            patient_id   = data["patient_id"],
            diagnosis    = data["diagnosis"],
            prescription = data["prescription"],
            notes        = data["notes"],
            record_date  = data.get("record_date"),
        )


# ============================================================
#  SECTION 10: LAB REPORT CLASS
# ============================================================

class LabReport:
    """
    Represents a laboratory test report for a patient.

    Attributes from PDF:
      report_id, patient_id, test_name, result, report_date
    """

    def __init__(self, report_id, patient_id, test_name,
                 result, report_date=None):
        self.__report_id   = report_id
        self.__patient_id  = patient_id
        self.__test_name   = test_name
        self.__result      = result
        self.__report_date = report_date if report_date else get_current_date()

    # ── Properties ───────────────────────────
    @property
    def report_id(self):
        return self.__report_id

    @property
    def patient_id(self):
        return self.__patient_id

    @property
    def test_name(self):
        return self.__test_name

    @property
    def result(self):
        return self.__result

    @property
    def report_date(self):
        return self.__report_date

    # ── Methods (from PDF) ────────────────────
    def generate_report(self):
        """Confirm report generation."""
        print(f"  [+] Lab report {self.__report_id} generated for Patient {self.__patient_id}.")
        print(f"      Test: {self.__test_name} | Date: {self.__report_date}")

    def display_report(self):
        """Display full lab report."""
        print(f"\n  ── Lab Report ───────────────────────────")
        print(f"  Report ID  : {self.__report_id}")
        print(f"  Patient ID : {self.__patient_id}")
        print(f"  Test Name  : {self.__test_name}")
        print(f"  Result     : {self.__result}")
        print(f"  Date       : {self.__report_date}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"LabReport[{self.__report_id}] "
                f"Patient:{self.__patient_id} | {self.__test_name} "
                f"| {self.__report_date}")

    def __repr__(self):
        return (f"LabReport(id={self.__report_id!r}, "
                f"patient={self.__patient_id!r}, "
                f"test={self.__test_name!r})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "report_id":   self.__report_id,
            "patient_id":  self.__patient_id,
            "test_name":   self.__test_name,
            "result":      self.__result,
            "report_date": self.__report_date,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            report_id   = data["report_id"],
            patient_id  = data["patient_id"],
            test_name   = data["test_name"],
            result      = data["result"],
            report_date = data.get("report_date"),
        )


# ============================================================
#  SECTION 11: BILL CLASS
# ============================================================

class Bill:
    """
    Represents a patient bill with consultation, medicine, and lab charges.

    Attributes from PDF:
      bill_id, patient_id, consultation_charge,
      medicine_charge, lab_charge, total_amount
    """

    def __init__(self, bill_id, patient_id,
                 consultation_charge=0.0,
                 medicine_charge=0.0,
                 lab_charge=0.0,
                 generated_on=None):
        self.__bill_id             = bill_id
        self.__patient_id          = patient_id
        self.__consultation_charge = float(consultation_charge)
        self.__medicine_charge     = float(medicine_charge)
        self.__lab_charge          = float(lab_charge)
        self.__total_amount        = 0.0
        self.__generated_on        = generated_on if generated_on else get_current_datetime()
        self.calculate_total()

    # ── Properties ───────────────────────────
    @property
    def bill_id(self):
        return self.__bill_id

    @property
    def patient_id(self):
        return self.__patient_id

    @property
    def consultation_charge(self):
        return self.__consultation_charge

    @property
    def medicine_charge(self):
        return self.__medicine_charge

    @property
    def lab_charge(self):
        return self.__lab_charge

    @property
    def total_amount(self):
        return self.__total_amount

    @property
    def generated_on(self):
        return self.__generated_on

    @consultation_charge.setter
    def consultation_charge(self, value):
        if value >= 0:
            self.__consultation_charge = float(value)
            self.calculate_total()

    @medicine_charge.setter
    def medicine_charge(self, value):
        if value >= 0:
            self.__medicine_charge = float(value)
            self.calculate_total()

    @lab_charge.setter
    def lab_charge(self, value):
        if value >= 0:
            self.__lab_charge = float(value)
            self.calculate_total()

    # ── Methods (from PDF) ────────────────────
    def calculate_total(self):
        """
        Calculate and store total bill amount.
        Raises InvalidBillAmountError if any charge is negative.
        """
        if (self.__consultation_charge < 0 or
                self.__medicine_charge < 0 or
                self.__lab_charge < 0):
            raise InvalidBillAmountError(
                f"C:{self.__consultation_charge} "
                f"M:{self.__medicine_charge} "
                f"L:{self.__lab_charge}"
            )
        self.__total_amount = (self.__consultation_charge
                               + self.__medicine_charge
                               + self.__lab_charge)
        return self.__total_amount

    def generate_receipt(self):
        """Print a formatted bill receipt."""
        print(f"\n  {'=' * 44}")
        print(f"  {'HOSPITAL BILL RECEIPT':^44}")
        print(f"  {'=' * 44}")
        print(f"  Bill ID          : {self.__bill_id}")
        print(f"  Patient ID       : {self.__patient_id}")
        print(f"  Generated On     : {self.__generated_on}")
        print(f"  {'-' * 44}")
        print(f"  Consultation     : Rs. {self.__consultation_charge:>10.2f}")
        print(f"  Medicine         : Rs. {self.__medicine_charge:>10.2f}")
        print(f"  Laboratory       : Rs. {self.__lab_charge:>10.2f}")
        print(f"  {'-' * 44}")
        print(f"  TOTAL AMOUNT     : Rs. {self.__total_amount:>10.2f}")
        print(f"  {'=' * 44}")

    # ── Magic Methods ─────────────────────────
    def __str__(self):
        return (f"Bill[{self.__bill_id}] Patient:{self.__patient_id} "
                f"| Total: Rs.{self.__total_amount:.2f}")

    def __repr__(self):
        return (f"Bill(id={self.__bill_id!r}, patient={self.__patient_id!r}, "
                f"total={self.__total_amount})")

    # ── Serialization ─────────────────────────
    def to_dict(self):
        return {
            "bill_id":             self.__bill_id,
            "patient_id":          self.__patient_id,
            "consultation_charge": self.__consultation_charge,
            "medicine_charge":     self.__medicine_charge,
            "lab_charge":          self.__lab_charge,
            "total_amount":        self.__total_amount,
            "generated_on":        self.__generated_on,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            bill_id             = data["bill_id"],
            patient_id          = data["patient_id"],
            consultation_charge = data["consultation_charge"],
            medicine_charge     = data["medicine_charge"],
            lab_charge          = data["lab_charge"],
            generated_on        = data.get("generated_on"),
        )


# ============================================================
#  SECTION 12: HOSPITAL CLASS (Composition)
# ============================================================

# ── File paths ────────────────────────────────
_BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_DIR     = os.path.join(_BASE_DIR, "data")
REPORTS_DIR  = os.path.join(_BASE_DIR, "reports")

FILES = {
    "patients":        os.path.join(DATA_DIR, "patients.json"),
    "doctors":         os.path.join(DATA_DIR, "doctors.json"),
    "nurses":          os.path.join(DATA_DIR, "nurses.json"),
    "appointments":    os.path.join(DATA_DIR, "appointments.json"),
    "medicines":       os.path.join(DATA_DIR, "medicines.json"),
    "medical_records": os.path.join(DATA_DIR, "medical_records.json"),
    "lab_reports":     os.path.join(DATA_DIR, "lab_reports.json"),
    "bills":           os.path.join(DATA_DIR, "bills.json"),
}


class Hospital:
    """
    Central class that contains ALL other objects — Composition pattern.

    Data Structures Used:
      patients        → dict   {patient_id: Patient}
      doctors         → dict   {doctor_id: Doctor}
      nurses          → dict   {nurse_id: Nurse}
      medicines       → dict   {medicine_id: Medicine}
      appointments    → list   [Appointment, ...]
      medical_records → list   [MedicalRecord, ...]
      lab_reports     → list   [LabReport, ...]
      bills           → list   [Bill, ...]
      departments     → set    (unique department names)
    """

    HOSPITAL_NAME  = "Smart City Hospital"
    HOSPITAL_RULES = [
        "All patients must register before consultation.",
        "Appointments must be booked at least one day in advance.",
        "Bills must be settled before discharge.",
        "Medicines will only be dispensed with a valid prescription.",
        "Lab reports are generated within 24 hours of sample collection.",
    ]

    def __init__(self):
        self.patients:        dict = {}
        self.doctors:         dict = {}
        self.nurses:          dict = {}
        self.medicines:       dict = {}
        self.appointments:    list = []
        self.medical_records: list = []
        self.lab_reports:     list = []
        self.bills:           list = []
        self.departments:     set  = set()   # Set — PDF requirement
        os.makedirs(DATA_DIR, exist_ok=True)
        os.makedirs(REPORTS_DIR, exist_ok=True)

    # ── Static Methods ────────────────────────
    @staticmethod
    def display_hospital_rules():
        """Static Method: Display hospital rules and regulations."""
        print_header("HOSPITAL RULES & REGULATIONS")
        for i, rule in enumerate(Hospital.HOSPITAL_RULES, 1):
            print(f"  {i}. {rule}")

    @staticmethod
    def get_hospital_name():
        """Static Method: Return the hospital name."""
        return Hospital.HOSPITAL_NAME

    # ── Class Methods ─────────────────────────
    @classmethod
    def get_version(cls):
        """Class Method: Return system version string."""
        return "Smart Hospital Management System v1.0"

    def get_statistics(self):
        """
        Generate hospital-wide statistics.
        (PDF: Class Methods — hospital-wide statistics)
        """
        total_revenue = sum(b.total_amount for b in self.bills)
        # List Comprehension (PDF requirement)
        active_appts = [a for a in self.appointments if a.status == "Scheduled"]
        print_header("HOSPITAL STATISTICS")
        print(f"  Total Patients      : {len(self.patients)}")
        print(f"  Total Doctors       : {len(self.doctors)}")
        print(f"  Total Nurses        : {len(self.nurses)}")
        print(f"  Total Appointments  : {len(self.appointments)}")
        print(f"  Active Appointments : {len(active_appts)}")
        print(f"  Total Medicines     : {len(self.medicines)}")
        print(f"  Medical Records     : {len(self.medical_records)}")
        print(f"  Lab Reports         : {len(self.lab_reports)}")
        print(f"  Total Bills         : {len(self.bills)}")
        print(f"  Total Revenue       : Rs. {total_revenue:.2f}")
        print(f"  Departments (Set)   : {self.departments if self.departments else 'None yet'}")

    # ── Patient Management ────────────────────
    @log_action("PATIENT_REGISTRATION")
    def register_patient(self, name, age, gender, phone, blood_group):
        """Register a new patient. Decorated with @log_action."""
        patient_id = generate_patient_id(self.patients)
        patient = Patient(patient_id, name, age, gender, phone, blood_group)
        self.patients[patient_id] = patient
        print(f"  [+] Patient registered successfully: {patient_id}")
        return patient

    def update_patient(self, patient_id, name=None, age=None, phone=None):
        """Update patient details."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        p = self.patients[patient_id]
        if name:  p.name  = name
        if age:   p.age   = int(age)
        if phone: p.phone = phone
        print(f"  [~] Patient {patient_id} updated.")

    def search_patient(self, query):
        """Search patient by ID or name using list comprehension."""
        query = query.lower().strip()
        if query.upper() in self.patients:
            return [self.patients[query.upper()]]
        # List Comprehension (PDF requirement)
        return [p for p in self.patients.values() if query in p.name.lower()]

    def search_patient_recursive(self, name_query, patient_list=None,
                                 index=0, results=None):
        """
        Recursive patient search by name.
        PDF requirement: Recursive Function
        """
        if results is None:
            results = []
        if patient_list is None:
            patient_list = list(self.patients.values())
        if index >= len(patient_list):
            return results
        if name_query.lower() in patient_list[index].name.lower():
            results.append(patient_list[index])
        # Recursive call
        return self.search_patient_recursive(
            name_query, patient_list, index + 1, results
        )

    def view_patient_history(self, patient_id):
        """View full medical history for a patient."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        patient = self.patients[patient_id]
        patient.display_details()
        records = [r for r in self.medical_records if r.patient_id == patient_id]
        if records:
            print(f"\n  Medical Records ({len(records)}):")
            for rec in records:
                rec.view_record()
        else:
            print("  No medical records on file.")

    def get_active_patients(self):
        """
        List Comprehension: Return patients with at least one appointment.
        PDF requirement: List Comprehension
        """
        return [p for p in self.patients.values() if len(p.appointments) > 0]

    # ── Doctor Management ─────────────────────
    def add_doctor(self, name, age, gender, phone,
                   specialization, consultation_fee):
        """Add a new doctor to the system."""
        doctor_id = generate_doctor_id(self.doctors)
        doctor = Doctor(doctor_id, name, age, gender, phone,
                        specialization, consultation_fee)
        self.doctors[doctor_id] = doctor
        print(f"  [+] Doctor added: {doctor_id} - Dr. {name}")
        return doctor

    def update_doctor(self, doctor_id, specialization=None,
                      consultation_fee=None, phone=None):
        """Update doctor information."""
        if doctor_id not in self.doctors:
            raise InvalidDoctorIDError(doctor_id)
        d = self.doctors[doctor_id]
        if specialization:   d.specialization   = specialization
        if consultation_fee: d.consultation_fee = float(consultation_fee)
        if phone:            d.phone            = phone
        print(f"  [~] Doctor {doctor_id} updated.")

    def list_doctors_by_fee(self):
        """Lambda: Sort and list doctors by consultation fee."""
        sorted_docs = sort_doctors_by_fee(list(self.doctors.values()))
        print_header("DOCTORS SORTED BY CONSULTATION FEE")
        if not sorted_docs:
            print("  No doctors registered.")
            return
        for doc in sorted_docs:
            print(f"  {doc}")

    # ── Nurse Management ──────────────────────
    def add_nurse(self, name, age, gender, phone, department, shift):
        """Add a new nurse and track department in the departments set."""
        nurse_id = generate_nurse_id(self.nurses)
        nurse = Nurse(nurse_id, name, age, gender, phone, department, shift)
        self.nurses[nurse_id] = nurse
        self.departments.add(department)   # Set — PDF requirement
        print(f"  [+] Nurse added: {nurse_id} - {name} | Dept: {department}")
        return nurse

    def update_nurse(self, nurse_id, department=None, shift=None):
        """Update nurse department or shift."""
        if nurse_id not in self.nurses:
            raise InvalidNurseIDError(nurse_id)
        n = self.nurses[nurse_id]
        if department:
            n.department = department
            self.departments.add(department)
        if shift:
            n.update_shift(shift)
        print(f"  [~] Nurse {nurse_id} updated.")

    def list_nurses_by_department(self):
        """Display nurses grouped by department using list comprehension."""
        print_header("NURSES BY DEPARTMENT")
        if not self.departments:
            print("  No departments registered.")
            return
        for dept in sorted(self.departments):
            nurses_in_dept = [n for n in self.nurses.values()
                              if n.department == dept]
            print(f"\n  Department: {dept} ({len(nurses_in_dept)} nurse(s))")
            for n in nurses_in_dept:
                print(f"    {n}")

    # ── Appointment Management ────────────────
    @log_action("APPOINTMENT_BOOKING")
    def book_appointment(self, patient_id, doctor_id, date, slot):
        """
        Book appointment with full validation.
        Decorated with @log_action.
        """
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        if doctor_id not in self.doctors:
            raise InvalidDoctorIDError(doctor_id)
        doctor = self.doctors[doctor_id]
        if slot not in doctor.available_slots:
            raise SlotNotAvailableError(doctor_id, slot)
        conflict = any(
            a.doctor_id == doctor_id and
            a.appointment_date == date and
            a.slot == slot and
            a.status != "Cancelled"
            for a in self.appointments
        )
        if conflict:
            raise AppointmentConflictError(doctor_id, date, slot)
        appt_id = generate_appointment_id(self.appointments)
        appt = Appointment(appt_id, patient_id, doctor_id, date, slot)
        appt.book()
        self.appointments.append(appt)
        self.patients[patient_id].book_appointment(appt_id)
        return appt

    def cancel_appointment(self, appointment_id):
        """Cancel an appointment by ID."""
        for appt in self.appointments:
            if appt.appointment_id == appointment_id:
                appt.cancel()
                return
        print(f"  [!] Appointment {appointment_id} not found.")

    def reschedule_appointment(self, appointment_id, new_date, new_slot):
        """Reschedule an appointment to a new date and slot."""
        for appt in self.appointments:
            if appt.appointment_id == appointment_id:
                appt.reschedule(new_date, new_slot)
                return
        print(f"  [!] Appointment {appointment_id} not found.")

    def view_appointments(self, filter_status=None):
        """Display all appointments sorted by date (lambda sort)."""
        appts = self.appointments
        if filter_status:
            appts = [a for a in appts if a.status == filter_status]
        appts = sort_appointments_by_date(appts)   # lambda
        if not appts:
            print("  No appointments found.")
            return
        for a in appts:
            a.display()

    # ── Pharmacy Management ───────────────────
    def add_medicine(self, name, stock, price, expiry_date):
        """Add a new medicine to the pharmacy inventory."""
        med_id = generate_medicine_id(self.medicines)
        med = Medicine(med_id, name, stock, price, expiry_date)
        self.medicines[med_id] = med
        print(f"  [+] Medicine added: {med_id} - {name}")
        return med

    def update_medicine_stock(self, medicine_id, quantity):
        """Add stock to an existing medicine."""
        if medicine_id not in self.medicines:
            print(f"  [!] Medicine ID {medicine_id} not found.")
            return
        self.medicines[medicine_id].add_stock(quantity)

    def dispense_medicine(self, medicine_id, quantity):
        """Reduce stock when medicine is dispensed."""
        if medicine_id not in self.medicines:
            print(f"  [!] Medicine ID {medicine_id} not found.")
            return 0.0
        med = self.medicines[medicine_id]
        med.reduce_stock(quantity)
        return med.price * quantity

    def check_medicine_availability(self, medicine_id):
        """Check availability and expiry of a medicine."""
        if medicine_id not in self.medicines:
            print(f"  [!] Medicine {medicine_id} not found.")
            return
        self.medicines[medicine_id].display()

    def list_medicines_by_price(self):
        """Lambda: List all medicines sorted by price."""
        sorted_meds = sort_medicines_by_price(list(self.medicines.values()))
        print_header("MEDICINES SORTED BY PRICE")
        if not sorted_meds:
            print("  No medicines in inventory.")
            return
        for m in sorted_meds:
            print(f"  {m}")

    def check_expiring_medicines(self):
        """Display medicines expiring within 30 days or already expired."""
        print_header("EXPIRY CHECK — NEXT 30 DAYS")
        today = datetime.date.today()
        warning_date = today + datetime.timedelta(days=30)
        found = False
        for med in self.medicines.values():
            exp = datetime.datetime.strptime(med.expiry_date, "%Y-%m-%d").date()
            if exp <= warning_date:
                tag = "[EXPIRED]" if exp < today else "[EXPIRING SOON]"
                print(f"  {tag} {med}")
                found = True
        if not found:
            print("  All medicines are within expiry limits.")

    # ── Medical Record Management ─────────────
    def add_medical_record(self, patient_id, diagnosis, prescription, notes):
        """Add a medical record for a patient."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        record_id = generate_record_id(self.medical_records)
        record = MedicalRecord(record_id, patient_id, diagnosis,
                               prescription, notes)
        record.add_record()
        self.medical_records.append(record)
        self.patients[patient_id].add_medical_history(record_id)
        return record

    def view_medical_records(self, patient_id):
        """View all medical records for a specific patient."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        records = [r for r in self.medical_records
                   if r.patient_id == patient_id]
        if not records:
            print(f"  No medical records found for {patient_id}.")
            return
        for rec in records:
            rec.view_record()

    # ── Laboratory Management ─────────────────
    def generate_lab_report(self, patient_id, test_name, result):
        """Generate a lab report for a patient."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        report_id = generate_report_id(self.lab_reports)
        report = LabReport(report_id, patient_id, test_name, result)
        report.generate_report()
        self.lab_reports.append(report)
        return report

    def view_lab_reports(self, patient_id):
        """View all lab reports for a specific patient."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        reports = [r for r in self.lab_reports
                   if r.patient_id == patient_id]
        if not reports:
            print(f"  No lab reports found for {patient_id}.")
            return
        for rep in reports:
            rep.display_report()

    # ── Billing Management ────────────────────
    @log_action("BILL_GENERATION")
    def generate_bill(self, patient_id, consultation_charge=0.0,
                      medicine_charge=0.0, lab_charge=0.0):
        """Generate a bill for a patient. Decorated with @log_action."""
        if patient_id not in self.patients:
            raise InvalidPatientIDError(patient_id)
        bill_id = generate_bill_id(self.bills)
        bill = Bill(bill_id, patient_id,
                    consultation_charge, medicine_charge, lab_charge)
        self.bills.append(bill)
        bill.generate_receipt()
        return bill

    def view_patient_bills(self, patient_id):
        """View all bills for a specific patient."""
        bills = [b for b in self.bills if b.patient_id == patient_id]
        if not bills:
            print(f"  No bills found for {patient_id}.")
            return
        for b in bills:
            b.generate_receipt()

    # ── JSON File Handling ────────────────────
    def save_data(self):
        """
        Save all hospital data to JSON files.
        Creates files automatically if they don't exist.
        PDF requirement: JSON File Handling
        """
        print_header("SAVING DATA TO FILES")
        try:
            with open(FILES["patients"], "w") as f:
                json.dump({k: v.to_dict() for k, v in self.patients.items()}, f, indent=2)
            print(f"  [+] Patients saved      ({len(self.patients)} records)")

            with open(FILES["doctors"], "w") as f:
                json.dump({k: v.to_dict() for k, v in self.doctors.items()}, f, indent=2)
            print(f"  [+] Doctors saved       ({len(self.doctors)} records)")

            with open(FILES["nurses"], "w") as f:
                json.dump({k: v.to_dict() for k, v in self.nurses.items()}, f, indent=2)
            print(f"  [+] Nurses saved        ({len(self.nurses)} records)")

            with open(FILES["appointments"], "w") as f:
                json.dump([a.to_dict() for a in self.appointments], f, indent=2)
            print(f"  [+] Appointments saved  ({len(self.appointments)} records)")

            with open(FILES["medicines"], "w") as f:
                json.dump({k: v.to_dict() for k, v in self.medicines.items()}, f, indent=2)
            print(f"  [+] Medicines saved     ({len(self.medicines)} records)")

            with open(FILES["medical_records"], "w") as f:
                json.dump([r.to_dict() for r in self.medical_records], f, indent=2)
            print(f"  [+] Medical records saved ({len(self.medical_records)} records)")

            with open(FILES["lab_reports"], "w") as f:
                json.dump([r.to_dict() for r in self.lab_reports], f, indent=2)
            print(f"  [+] Lab reports saved   ({len(self.lab_reports)} records)")

            with open(FILES["bills"], "w") as f:
                json.dump([b.to_dict() for b in self.bills], f, indent=2)
            print(f"  [+] Bills saved         ({len(self.bills)} records)")

            print(f"\n  [✓] All data saved successfully at {get_current_datetime()}")
        except Exception as e:
            print(f"  [!] Error saving data: {e}")

    def load_data(self):
        """
        Load all hospital data from JSON files.
        Handles MissingFileError gracefully — starts with empty data.
        PDF requirement: JSON File Handling
        """
        print_header("LOADING DATA FROM FILES")
        loaded_ok = []
        errors    = []

        try:
            with open(FILES["patients"], "r") as f:
                data = json.load(f)
                self.patients = {k: Patient.from_dict(v) for k, v in data.items()}
            loaded_ok.append(f"Patients ({len(self.patients)})")
        except FileNotFoundError:
            errors.append("patients.json not found")
            self.patients = {}

        try:
            with open(FILES["doctors"], "r") as f:
                data = json.load(f)
                self.doctors = {k: Doctor.from_dict(v) for k, v in data.items()}
            loaded_ok.append(f"Doctors ({len(self.doctors)})")
        except FileNotFoundError:
            errors.append("doctors.json not found")
            self.doctors = {}

        try:
            with open(FILES["nurses"], "r") as f:
                data = json.load(f)
                self.nurses = {k: Nurse.from_dict(v) for k, v in data.items()}
                self.departments = set(n.department for n in self.nurses.values())
            loaded_ok.append(f"Nurses ({len(self.nurses)})")
        except FileNotFoundError:
            errors.append("nurses.json not found")
            self.nurses = {}

        try:
            with open(FILES["appointments"], "r") as f:
                data = json.load(f)
                self.appointments = [Appointment.from_dict(a) for a in data]
            loaded_ok.append(f"Appointments ({len(self.appointments)})")
        except FileNotFoundError:
            errors.append("appointments.json not found")
            self.appointments = []

        try:
            with open(FILES["medicines"], "r") as f:
                data = json.load(f)
                self.medicines = {k: Medicine.from_dict(v) for k, v in data.items()}
            loaded_ok.append(f"Medicines ({len(self.medicines)})")
        except FileNotFoundError:
            errors.append("medicines.json not found")
            self.medicines = {}

        try:
            with open(FILES["medical_records"], "r") as f:
                data = json.load(f)
                self.medical_records = [MedicalRecord.from_dict(r) for r in data]
            loaded_ok.append(f"Medical Records ({len(self.medical_records)})")
        except FileNotFoundError:
            errors.append("medical_records.json not found")
            self.medical_records = []

        try:
            with open(FILES["lab_reports"], "r") as f:
                data = json.load(f)
                self.lab_reports = [LabReport.from_dict(r) for r in data]
            loaded_ok.append(f"Lab Reports ({len(self.lab_reports)})")
        except FileNotFoundError:
            errors.append("lab_reports.json not found")
            self.lab_reports = []

        try:
            with open(FILES["bills"], "r") as f:
                data = json.load(f)
                self.bills = [Bill.from_dict(b) for b in data]
            loaded_ok.append(f"Bills ({len(self.bills)})")
        except FileNotFoundError:
            errors.append("bills.json not found")
            self.bills = []

        if loaded_ok:
            print(f"  [✓] Loaded: {', '.join(loaded_ok)}")
        if errors:
            for err in errors:
                print(f"  [i] {err} — will be created on Save.")

    # ── CSV Report Generation ─────────────────
    def generate_appointment_report_csv(self):
        """
        Generate daily appointment CSV report using a Generator.
        PDF requirement: CSV Files + Generators
        """
        filename = os.path.join(
            REPORTS_DIR,
            f"appointment_report_{get_current_date()}.csv"
        )
        if not self.appointments:
            print("  [!] No appointments to export.")
            return
        fieldnames = ["Appointment ID", "Patient ID", "Doctor ID",
                      "Date", "Slot", "Status"]
        with open(filename, "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in appointment_report_generator(self.appointments):  # Generator
                writer.writerow(row)
        print(f"  [+] Appointment report: {filename}")

    def generate_billing_report_csv(self):
        """
        Generate billing CSV report using a Generator.
        PDF requirement: CSV Files + Generators
        """
        filename = os.path.join(
            REPORTS_DIR,
            f"billing_report_{get_current_date()}.csv"
        )
        if not self.bills:
            print("  [!] No bills to export.")
            return
        fieldnames = ["Bill ID", "Patient ID", "Consultation Charge",
                      "Medicine Charge", "Lab Charge",
                      "Total Amount", "Generated On"]
        with open(filename, "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in billing_report_generator(self.bills):  # Generator
                writer.writerow(row)
        print(f"  [+] Billing report: {filename}")

    def generate_lab_report_csv(self):
        """Generate lab report CSV using a Generator."""
        filename = os.path.join(
            REPORTS_DIR,
            f"lab_report_{get_current_date()}.csv"
        )
        if not self.lab_reports:
            print("  [!] No lab reports to export.")
            return
        fieldnames = ["Report ID", "Patient ID", "Test Name",
                      "Result", "Report Date"]
        with open(filename, "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in lab_report_generator(self.lab_reports):  # Generator
                writer.writerow(row)
        print(f"  [+] Lab report CSV: {filename}")

    def generate_reports(self):
        """Generate all CSV reports at once."""
        print_header("GENERATING ALL REPORTS")
        self.generate_appointment_report_csv()
        self.generate_billing_report_csv()
        self.generate_lab_report_csv()
        print(f"\n  [✓] Reports saved to: {REPORTS_DIR}")
