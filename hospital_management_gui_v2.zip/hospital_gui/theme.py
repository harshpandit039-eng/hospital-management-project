"""
theme.py — Centralized design tokens for the Smart Hospital Management System GUI.
Dark navy / clinical-red palette so every view stays visually consistent.
"""

import customtkinter as ctk

# ── Core Palette ────────────────────────────────────────────
BG_APP        = "#0B1220"   # outermost window background
BG_SIDEBAR    = "#0E1A2B"   # sidebar background
BG_SIDEBAR_HI = "#15263F"   # sidebar hover/active
BG_SURFACE    = "#101C30"   # cards / panels
BG_SURFACE_2  = "#16263F"   # nested panels, table headers
BG_INPUT      = "#0C1626"   # entry fields

BORDER        = "#22324A"
BORDER_SOFT   = "#1A283F"

TEXT_PRIMARY   = "#EAF1FB"
TEXT_SECONDARY = "#8CA0BC"
TEXT_MUTED     = "#5E7290"

ACCENT_RED      = "#E14B5A"   # primary accent — alerts, vitals, CTA
ACCENT_RED_HI   = "#F26674"
ACCENT_TEAL     = "#33C7B6"   # secondary accent — positive stats
ACCENT_GOLD     = "#E8B14B"   # warnings / pending
ACCENT_BLUE     = "#4C8DFF"   # informational / links
ACCENT_GREEN    = "#3FCF7F"   # success

STATUS_COLORS = {
    "Scheduled":   ACCENT_BLUE,
    "Completed":   ACCENT_GREEN,
    "Cancelled":   ACCENT_RED,
    "Rescheduled": ACCENT_GOLD,
}

# ── Typography ───────────────────────────────────────────────
FONT_FAMILY = "Helvetica"

def font(size=13, weight="normal"):
    return ctk.CTkFont(family=FONT_FAMILY, size=size, weight=weight)

FONT_H1     = lambda: font(26, "bold")
FONT_H2     = lambda: font(18, "bold")
FONT_H3     = lambda: font(14, "bold")
FONT_BODY   = lambda: font(13, "normal")
FONT_SMALL  = lambda: font(11, "normal")
FONT_MONO   = lambda: ctk.CTkFont(family="Courier New", size=12)
FONT_STAT   = lambda: font(28, "bold")
FONT_LOGO   = lambda: font(17, "bold")

# ── Geometry ─────────────────────────────────────────────────
RADIUS       = 12
RADIUS_SM    = 8
PAD          = 16
SIDEBAR_W    = 230

NAV_ITEMS = [
    ("dashboard",    "🏠  Dashboard"),
    ("patients",     "🧑‍🤝‍🧑  Patients"),
    ("doctors",      "🩺  Doctors"),
    ("nurses",       "👩‍⚕️  Nurses"),
    ("appointments", "📅  Appointments"),
    ("pharmacy",     "💊  Pharmacy"),
    ("records",      "📋  Medical Records"),
    ("lab",          "🧪  Lab Reports"),
    ("billing",      "🧾  Billing"),
    ("reports",      "📊  Reports & Data"),
]


def style_treeview(style, row_height=34):
    """Apply the dark theme to a ttk.Treeview used across table views."""
    style.theme_use("default")
    style.configure(
        "Hospital.Treeview",
        background=BG_SURFACE,
        fieldbackground=BG_SURFACE,
        foreground=TEXT_PRIMARY,
        borderwidth=0,
        rowheight=row_height,
        font=(FONT_FAMILY, 12),
    )
    style.configure(
        "Hospital.Treeview.Heading",
        background=BG_SURFACE_2,
        foreground=TEXT_SECONDARY,
        borderwidth=0,
        font=(FONT_FAMILY, 11, "bold"),
        relief="flat",
    )
    style.map(
        "Hospital.Treeview",
        background=[("selected", "#1E3A5F")],
        foreground=[("selected", TEXT_PRIMARY)],
    )
    style.map(
        "Hospital.Treeview.Heading",
        background=[("active", BG_SURFACE_2)],
    )
    style.layout(
        "Hospital.Treeview",
        [("Hospital.Treeview.treearea", {"sticky": "nswe"})],
    )
