"""
charts.py — Small matplotlib helpers that return a Tk-embeddable canvas,
pre-styled to match the dashboard's dark navy theme.
"""

import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import theme as T

matplotlib.rcParams["font.family"] = "DejaVu Sans"


def _new_figure(figsize):
    fig = Figure(figsize=figsize, dpi=100)
    fig.patch.set_facecolor(T.BG_SURFACE)
    return fig


def _style_axes(ax):
    ax.set_facecolor(T.BG_SURFACE)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(colors=T.TEXT_SECONDARY, labelsize=9)
    ax.title.set_color(T.TEXT_PRIMARY)


def donut_chart(master, labels, values, colors, title="", figsize=(4.0, 3.1)):
    fig = _new_figure(figsize)
    ax = fig.add_subplot(111)
    if sum(values) == 0:
        ax.text(0.5, 0.5, "No data yet", ha="center", va="center",
                 color=T.TEXT_MUTED, fontsize=11, transform=ax.transAxes)
        ax.axis("off")
    else:
        wedges, _ = ax.pie(
            values, colors=colors, startangle=90,
            wedgeprops=dict(width=0.42, edgecolor=T.BG_SURFACE, linewidth=2),
        )
        ax.legend(
            wedges, [f"{l} ({v})" for l, v in zip(labels, values)],
            loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False,
            fontsize=9, labelcolor=T.TEXT_SECONDARY,
        )
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", pad=10)
    fig.tight_layout()
    canvas = FigureCanvasTkAgg(fig, master=master)
    canvas.draw()
    return canvas.get_tk_widget()


def bar_chart(master, labels, values, color=None, title="", horizontal=False, figsize=(4.4, 3.1)):
    color = color or T.ACCENT_BLUE
    fig = _new_figure(figsize)
    ax = fig.add_subplot(111)
    _style_axes(ax)
    if not labels or sum(values) == 0:
        ax.text(0.5, 0.5, "No data yet", ha="center", va="center",
                 color=T.TEXT_MUTED, fontsize=11, transform=ax.transAxes)
        ax.axis("off")
    elif horizontal:
        bars = ax.barh(labels, values, color=color, height=0.55)
        ax.invert_yaxis()
        ax.grid(axis="x", color=T.BORDER_SOFT, linewidth=0.6)
        for b in bars:
            ax.text(b.get_width() + max(values) * 0.02, b.get_y() + b.get_height() / 2,
                    f"{b.get_width():.0f}", va="center", color=T.TEXT_SECONDARY, fontsize=9)
    else:
        bars = ax.bar(labels, values, color=color, width=0.55)
        ax.grid(axis="y", color=T.BORDER_SOFT, linewidth=0.6)
        ax.tick_params(axis="x", rotation=20)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", pad=10)
    fig.tight_layout()
    canvas = FigureCanvasTkAgg(fig, master=master)
    canvas.draw()
    return canvas.get_tk_widget()


def line_chart(master, x_labels, values, color=None, title="", figsize=(4.4, 3.1)):
    color = color or T.ACCENT_TEAL
    fig = _new_figure(figsize)
    ax = fig.add_subplot(111)
    _style_axes(ax)
    if not x_labels or sum(values) == 0:
        ax.text(0.5, 0.5, "No data yet", ha="center", va="center",
                 color=T.TEXT_MUTED, fontsize=11, transform=ax.transAxes)
        ax.axis("off")
    else:
        ax.plot(x_labels, values, color=color, linewidth=2.2, marker="o", markersize=4)
        ax.fill_between(range(len(x_labels)), values, color=color, alpha=0.12)
        ax.grid(axis="y", color=T.BORDER_SOFT, linewidth=0.6)
        step = max(1, len(x_labels) // 6)
        ax.set_xticks(list(range(0, len(x_labels), step)))
        ax.set_xticklabels([x_labels[i] for i in range(0, len(x_labels), step)], rotation=20)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", pad=10)
    fig.tight_layout()
    canvas = FigureCanvasTkAgg(fig, master=master)
    canvas.draw()
    return canvas.get_tk_widget()
