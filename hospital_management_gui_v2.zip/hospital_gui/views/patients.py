"""views/patients.py — Patient registration, search, update, and history."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage
import models as m


class PatientsView(ListPage):
    title = "Patients"
    subtitle = "Register new patients and manage their records"
    search_placeholder = "Search by ID or name…"
    columns = [
        ("id", "Patient ID", 90),
        ("name", "Name", 170),
        ("age", "Age", 60),
        ("gender", "Gender", 90),
        ("phone", "Phone", 120),
        ("blood", "Blood Group", 100),
        ("appts", "Appointments", 100),
        ("records", "Records", 80),
    ]

    def header_actions(self):
        return [{"text": "+ Register Patient", "command": self.add_patient, "primary": True}]

    def toolbar_actions(self):
        return [("Edit", self.edit_patient), ("View History", self.view_history)]

    def load_rows(self):
        rows = []
        for p in self.hospital.patients.values():
            rows.append((p.patient_id, p.name, p.age, p.gender, p.phone,
                        p.blood_group, len(p.appointments), len(p.medical_history)))
        return rows

    # ── actions ──────────────────────────────────────────
    def add_patient(self):
        fields = [
            {"key": "name", "label": "Full Name", "placeholder": "e.g. Rohan Sharma"},
            {"key": "age", "label": "Age", "placeholder": "e.g. 34"},
            {"key": "gender", "label": "Gender", "kind": "option", "options": ["Male", "Female", "Other"]},
            {"key": "phone", "label": "Phone Number", "placeholder": "e.g. 9876543210"},
            {"key": "blood_group", "label": "Blood Group", "kind": "option",
             "options": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]},
        ]

        def submit(values):
            if not values["name"]:
                return False, "Name is required."
            if not values["age"].isdigit() or not (1 <= int(values["age"]) <= 120):
                return False, "Age must be a number between 1 and 120."
            if not values["phone"]:
                return False, "Phone number is required."
            try:
                p = self.hospital.register_patient(
                    values["name"], int(values["age"]), values["gender"],
                    values["phone"], values["blood_group"],
                )
                self.after_mutation(f"Patient {p.patient_id} registered.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Register New Patient", fields, submit, submit_text="Register")

    def edit_patient(self):
        row = self.require_selection()
        if not row:
            return
        pid = row[0]
        patient = self.hospital.patients.get(pid)
        if not patient:
            return
        fields = [
            {"key": "name", "label": "Full Name", "default": patient.name},
            {"key": "age", "label": "Age", "default": str(patient.age)},
            {"key": "phone", "label": "Phone Number", "default": patient.phone},
            {"key": "blood_group", "label": "Blood Group", "kind": "option",
             "options": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
             "default": patient.blood_group},
        ]

        def submit(values):
            try:
                self.hospital.update_patient(pid, values["name"] or None,
                                              values["age"] or None, values["phone"] or None)
                if values["blood_group"] and values["blood_group"] != patient.blood_group:
                    patient.blood_group = values["blood_group"]
                self.after_mutation(f"Patient {pid} updated.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Edit Patient — {pid}", fields, submit)

    def view_history(self):
        row = self.require_selection()
        if not row:
            return
        pid = row[0]
        patient = self.hospital.patients.get(pid)
        if not patient:
            return

        details = [
            f"Name: {patient.name}",
            f"Age: {patient.age}   Gender: {patient.gender}",
            f"Phone: {patient.phone}   Blood Group: {patient.blood_group}",
        ]
        appts = [a for a in self.hospital.appointments if a.patient_id == pid]
        appt_lines = [
            f"{a.appointment_id} — Dr. {self.hospital.doctors[a.doctor_id].name if a.doctor_id in self.hospital.doctors else a.doctor_id} "
            f"on {a.appointment_date} at {a.slot}  [{a.status}]"
            for a in appts
        ]
        records = [r for r in self.hospital.medical_records if r.patient_id == pid]
        record_lines = [f"{r.record_date} — {r.diagnosis} (Rx: {r.prescription})" for r in records]
        bills = [b for b in self.hospital.bills if b.patient_id == pid]
        bill_lines = [f"{b.bill_id} — ₹{b.total_amount:,.2f} on {b.generated_on}" for b in bills]

        sections = [
            ("Patient Details", details),
            (f"Appointments ({len(appts)})", appt_lines),
            (f"Medical Records ({len(records)})", record_lines),
            (f"Bills ({len(bills)})", bill_lines),
        ]
        W.DetailDialog(self.app, f"{patient.name} — {pid}", sections)
