"""views/pharmacy.py — Medicine inventory: stock, pricing, expiry tracking, dispensing."""

import datetime
import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage
import models as m


class PharmacyView(ListPage):
    title = "Pharmacy"
    subtitle = "Track inventory, restock, dispense, and monitor expiry"
    search_placeholder = "Search by ID or medicine name…"
    columns = [
        ("id", "Medicine ID", 100),
        ("name", "Name", 200),
        ("stock", "Stock", 80),
        ("price", "Price / Unit", 100),
        ("expiry", "Expiry Date", 110),
        ("status", "Status", 120),
    ]

    def header_actions(self):
        return [
            {"text": "Check Expiring", "command": self.check_expiring},
            {"text": "+ Add Medicine", "command": self.add_medicine, "primary": True},
        ]

    def toolbar_actions(self):
        return [("Add Stock", self.add_stock), ("Dispense", self.dispense)]

    def load_rows(self):
        rows = []
        today = datetime.date.today()
        for med in self.hospital.medicines.values():
            exp = datetime.datetime.strptime(med.expiry_date, "%Y-%m-%d").date()
            if exp < today:
                status = "Expired"
            elif exp <= today + datetime.timedelta(days=30):
                status = "Expiring Soon"
            elif med.stock < 10:
                status = "Low Stock"
            else:
                status = "OK"
            rows.append((med.medicine_id, med.medicine_name, med.stock,
                        f"₹{med.price:.2f}", med.expiry_date, status))
        return rows

    def add_medicine(self):
        fields = [
            {"key": "name", "label": "Medicine Name", "placeholder": "e.g. Paracetamol 650mg"},
            {"key": "stock", "label": "Initial Stock", "placeholder": "e.g. 100"},
            {"key": "price", "label": "Price per Unit (₹)", "placeholder": "e.g. 2.50"},
            {"key": "expiry_date", "label": "Expiry Date (YYYY-MM-DD)"},
        ]

        def submit(values):
            if not values["name"]:
                return False, "Medicine name is required."
            if not values["stock"].isdigit():
                return False, "Stock must be a whole number."
            try:
                price = float(values["price"])
            except ValueError:
                return False, "Price must be a number."
            if not m.is_valid_date(values["expiry_date"]):
                return False, "Expiry date must be in YYYY-MM-DD format."
            try:
                med = self.hospital.add_medicine(values["name"], int(values["stock"]), price,
                                                  values["expiry_date"])
                self.after_mutation(f"{med.medicine_name} added to inventory.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Add Medicine", fields, submit, submit_text="Add")

    def add_stock(self):
        row = self.require_selection()
        if not row:
            return
        mid = row[0]
        fields = [{"key": "qty", "label": "Quantity to Add", "placeholder": "e.g. 50"}]

        def submit(values):
            if not values["qty"].isdigit() or int(values["qty"]) <= 0:
                return False, "Enter a positive whole number."
            try:
                self.hospital.update_medicine_stock(mid, int(values["qty"]))
                self.after_mutation(f"Stock updated for {mid}.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Add Stock — {mid}", fields, submit, submit_text="Add Stock")

    def dispense(self):
        row = self.require_selection()
        if not row:
            return
        mid = row[0]
        fields = [{"key": "qty", "label": "Quantity to Dispense", "placeholder": "e.g. 10"}]

        def submit(values):
            if not values["qty"].isdigit() or int(values["qty"]) <= 0:
                return False, "Enter a positive whole number."
            try:
                cost = self.hospital.dispense_medicine(mid, int(values["qty"]))
                self.after_mutation(f"Dispensed — total cost ₹{cost:,.2f}.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Dispense — {mid}", fields, submit, submit_text="Dispense")

    def check_expiring(self):
        today = datetime.date.today()
        warning_date = today + datetime.timedelta(days=30)
        lines = []
        for med in self.hospital.medicines.values():
            exp = datetime.datetime.strptime(med.expiry_date, "%Y-%m-%d").date()
            if exp <= warning_date:
                tag = "EXPIRED" if exp < today else "EXPIRING SOON"
                lines.append(f"[{tag}] {med.medicine_name} — {med.stock} units, expires {med.expiry_date}")
        sections = [("Medicines Expiring Within 30 Days", lines)]
        W.DetailDialog(self.app, "Expiry Watchlist", sections)
