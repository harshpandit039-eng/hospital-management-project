"""views/reports.py — CSV report generation, JSON persistence, and hospital statistics."""

import os
import customtkinter as ctk

import theme as T
import widgets as W
import models as m


class ReportsView(ctk.CTkFrame):
    def __init__(self, master, hospital, app):
        super().__init__(master, fg_color="transparent")
        self.hospital = hospital
        self.app = app
        self._build()

    def _build(self):
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=28, pady=24)

        header = W.PageHeader(
            container, "Reports & Data",
            "Export CSV reports and manage persistent JSON storage",
            actions=[
                {"text": "Save Data", "command": self.save_data},
                {"text": "Load Data", "command": self.load_data},
                {"text": "Generate All Reports", "command": self.generate_all, "primary": True},
            ],
        )
        header.pack(fill="x", pady=(0, 20))

        body = ctk.CTkFrame(container, fg_color="transparent")
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=2)

        # ── Stats panel ──
        stats_card = ctk.CTkFrame(body, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                   border_width=1, border_color=T.BORDER_SOFT)
        stats_card.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        ctk.CTkLabel(stats_card, text="Hospital Statistics", font=T.FONT_H3(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w", padx=20, pady=(18, 10))
        self.stats_grid = ctk.CTkFrame(stats_card, fg_color="transparent")
        self.stats_grid.pack(fill="both", expand=True, padx=20, pady=(0, 20))

        # ── CSV export panel ──
        export_card = ctk.CTkFrame(body, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                    border_width=1, border_color=T.BORDER_SOFT)
        export_card.grid(row=0, column=1, sticky="nsew")
        ctk.CTkLabel(export_card, text="Individual CSV Exports", font=T.FONT_H3(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w", padx=20, pady=(18, 10))

        exports = [
            ("Appointment Report", self.export_appointments, f"{len(self.hospital.appointments)} appointments"),
            ("Billing Report", self.export_billing, f"{len(self.hospital.bills)} bills"),
            ("Lab Report", self.export_lab, f"{len(self.hospital.lab_reports)} lab reports"),
        ]
        for label, command, sub in exports:
            row = ctk.CTkFrame(export_card, fg_color=T.BG_SURFACE_2, corner_radius=T.RADIUS_SM)
            row.pack(fill="x", padx=20, pady=6)
            text_box = ctk.CTkFrame(row, fg_color="transparent")
            text_box.pack(side="left", padx=14, pady=10)
            ctk.CTkLabel(text_box, text=label, font=T.font(13, "bold"),
                         text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w")
            ctk.CTkLabel(text_box, text=sub, font=T.FONT_SMALL(),
                         text_color=T.TEXT_MUTED, anchor="w").pack(anchor="w")
            ctk.CTkButton(row, text="Export CSV", width=100, height=32, command=command,
                          fg_color=T.ACCENT_RED, hover_color=T.ACCENT_RED_HI,
                          text_color="#FFFFFF", font=T.font(12, "bold")).pack(side="right", padx=14)

        ctk.CTkFrame(export_card, height=14, fg_color="transparent").pack()

        path_label = ctk.CTkLabel(
            export_card,
            text=f"Files are written to:\n{m.REPORTS_DIR}",
            font=T.FONT_SMALL(), text_color=T.TEXT_MUTED, justify="left", anchor="w",
            wraplength=300,
        )
        path_label.pack(anchor="w", padx=20, pady=(0, 18))

        self.refresh()

    def refresh(self):
        for w in self.stats_grid.winfo_children():
            w.destroy()
        h = self.hospital
        active_appts = [a for a in h.appointments if a.status == "Scheduled"]
        total_revenue = sum(b.total_amount for b in h.bills)
        stats = [
            ("Total Patients", len(h.patients)),
            ("Total Doctors", len(h.doctors)),
            ("Total Nurses", len(h.nurses)),
            ("Total Appointments", len(h.appointments)),
            ("Active Appointments", len(active_appts)),
            ("Total Medicines", len(h.medicines)),
            ("Medical Records", len(h.medical_records)),
            ("Lab Reports", len(h.lab_reports)),
            ("Total Bills", len(h.bills)),
            ("Total Revenue", f"₹{total_revenue:,.2f}"),
            ("Departments Tracked", len(h.departments) if h.departments else 0),
        ]
        for i, (label, value) in enumerate(stats):
            row = ctk.CTkFrame(self.stats_grid, fg_color="transparent")
            row.pack(fill="x", pady=6)
            ctk.CTkLabel(row, text=label, font=T.FONT_BODY(), text_color=T.TEXT_SECONDARY,
                         anchor="w").pack(side="left")
            ctk.CTkLabel(row, text=str(value), font=T.font(13, "bold"), text_color=T.TEXT_PRIMARY,
                         anchor="e").pack(side="right")
        if h.departments:
            dep_row = ctk.CTkFrame(self.stats_grid, fg_color="transparent")
            dep_row.pack(fill="x", pady=(10, 0))
            ctk.CTkLabel(dep_row, text="Departments: " + ", ".join(sorted(h.departments)),
                         font=T.FONT_SMALL(), text_color=T.TEXT_MUTED, anchor="w",
                         wraplength=380, justify="left").pack(anchor="w")

    # ── actions ──────────────────────────────────────────
    def save_data(self):
        try:
            self.hospital.save_data()
            W.show_toast(self, "All data saved to JSON files.", kind="success")
        except Exception as e:
            W.show_toast(self, f"Save failed: {e}", kind="error")

    def load_data(self):
        def do_load():
            try:
                self.hospital.load_data()
                self.app.refresh_all()
                W.show_toast(self, "Data reloaded from disk.", kind="success")
            except Exception as e:
                W.show_toast(self, f"Load failed: {e}", kind="error")

        W.ConfirmDialog(
            self.app, "This replaces unsaved in-memory changes with the last saved JSON files. Continue?",
            do_load, title="Load Saved Data",
        )

    def export_appointments(self):
        self._export(self.hospital.generate_appointment_report_csv, "appointments")

    def export_billing(self):
        self._export(self.hospital.generate_billing_report_csv, "billing")

    def export_lab(self):
        self._export(self.hospital.generate_lab_report_csv, "lab reports")

    def _export(self, fn, label):
        try:
            fn()
            W.show_toast(self, f"{label.title()} CSV exported.", kind="success")
        except Exception as e:
            W.show_toast(self, f"Export failed: {e}", kind="error")

    def generate_all(self):
        try:
            self.hospital.generate_reports()
            W.show_toast(self, f"All reports exported to {os.path.basename(m.REPORTS_DIR)}/", kind="success")
        except Exception as e:
            W.show_toast(self, f"Export failed: {e}", kind="error")
