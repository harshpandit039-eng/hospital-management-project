"""views/doctors.py — Doctor roster, specialization/fee updates, and slot management."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage


class DoctorsView(ListPage):
    title = "Doctors"
    subtitle = "Manage the doctor roster, fees, and available slots"
    search_placeholder = "Search by ID, name, or specialization…"
    columns = [
        ("id", "Doctor ID", 90),
        ("name", "Name", 170),
        ("spec", "Specialization", 150),
        ("fee", "Consultation Fee", 130),
        ("phone", "Phone", 120),
        ("slots", "Available Slots", 110),
    ]

    def header_actions(self):
        return [{"text": "+ Add Doctor", "command": self.add_doctor, "primary": True}]

    def toolbar_actions(self):
        return [("Edit", self.edit_doctor), ("Manage Slots", self.manage_slots)]

    def load_rows(self):
        rows = []
        for d in self.hospital.doctors.values():
            rows.append((d.doctor_id, f"Dr. {d.name}", d.specialization,
                        f"₹{d.consultation_fee:,.0f}", d.phone, len(d.available_slots)))
        return rows

    def add_doctor(self):
        fields = [
            {"key": "name", "label": "Full Name", "placeholder": "e.g. Anjali Mehta"},
            {"key": "age", "label": "Age", "placeholder": "e.g. 42"},
            {"key": "gender", "label": "Gender", "kind": "option", "options": ["Male", "Female", "Other"]},
            {"key": "phone", "label": "Phone Number", "placeholder": "e.g. 9876543210"},
            {"key": "specialization", "label": "Specialization", "placeholder": "e.g. Cardiology"},
            {"key": "consultation_fee", "label": "Consultation Fee (₹)", "placeholder": "e.g. 500"},
        ]

        def submit(values):
            if not values["name"] or not values["specialization"]:
                return False, "Name and specialization are required."
            if not values["age"].isdigit():
                return False, "Age must be a number."
            try:
                fee = float(values["consultation_fee"])
            except ValueError:
                return False, "Consultation fee must be a number."
            try:
                d = self.hospital.add_doctor(values["name"], int(values["age"]), values["gender"],
                                              values["phone"], values["specialization"], fee)
                self.after_mutation(f"Dr. {d.name} added ({d.doctor_id}).")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Add New Doctor", fields, submit, submit_text="Add Doctor")

    def edit_doctor(self):
        row = self.require_selection()
        if not row:
            return
        did = row[0]
        doctor = self.hospital.doctors.get(did)
        if not doctor:
            return
        fields = [
            {"key": "specialization", "label": "Specialization", "default": doctor.specialization},
            {"key": "consultation_fee", "label": "Consultation Fee (₹)", "default": str(doctor.consultation_fee)},
            {"key": "phone", "label": "Phone Number", "default": doctor.phone},
        ]

        def submit(values):
            try:
                fee = float(values["consultation_fee"]) if values["consultation_fee"] else None
                self.hospital.update_doctor(did, values["specialization"] or None, fee, values["phone"] or None)
                self.after_mutation(f"Dr. {doctor.name} updated.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Edit Dr. {doctor.name}", fields, submit)

    def manage_slots(self):
        row = self.require_selection()
        if not row:
            return
        did = row[0]
        doctor = self.hospital.doctors.get(did)
        if not doctor:
            return
        SlotsDialog(self.app, doctor, on_change=lambda: self.after_mutation())


class SlotsDialog(ctk.CTkToplevel):
    """Add/remove available appointment slots for a single doctor."""

    def __init__(self, master, doctor, on_change):
        super().__init__(master)
        self.doctor = doctor
        self.on_change = on_change
        self.title(f"Manage Slots — Dr. {doctor.name}")
        self.geometry("380x460")
        self.configure(fg_color=T.BG_APP)
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.grab_set()

        ctk.CTkLabel(self, text=f"Dr. {doctor.name}", font=T.FONT_H2(),
                     text_color=T.TEXT_PRIMARY).pack(anchor="w", padx=22, pady=(20, 0))
        ctk.CTkLabel(self, text=doctor.specialization, font=T.FONT_BODY(),
                     text_color=T.TEXT_SECONDARY).pack(anchor="w", padx=22, pady=(0, 14))

        self.list_frame = ctk.CTkScrollableFrame(self, fg_color=T.BG_SURFACE, height=240)
        self.list_frame.pack(fill="both", expand=True, padx=22)
        self._render_slots()

        add_row = ctk.CTkFrame(self, fg_color="transparent")
        add_row.pack(fill="x", padx=22, pady=16)
        self.new_slot_var = ctk.StringVar()
        ctk.CTkEntry(add_row, textvariable=self.new_slot_var, placeholder_text="HH:MM e.g. 13:00",
                     fg_color=T.BG_INPUT, border_color=T.BORDER, text_color=T.TEXT_PRIMARY,
                     height=36).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(add_row, text="Add Slot", command=self._add_slot, height=36, width=90,
                      fg_color=T.ACCENT_RED, hover_color=T.ACCENT_RED_HI,
                      text_color="#FFFFFF", font=T.font(12, "bold")).pack(side="left", padx=(8, 0))

        ctk.CTkButton(self, text="Done", command=self.destroy, height=38,
                      fg_color=T.BG_SURFACE_2, hover_color=T.BORDER,
                      text_color=T.TEXT_PRIMARY, font=T.font(13, "bold")).pack(pady=(0, 18))

    def _render_slots(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        slots = self.doctor.available_slots
        if not slots:
            ctk.CTkLabel(self.list_frame, text="No slots configured.", text_color=T.TEXT_MUTED,
                         font=T.FONT_SMALL()).pack(pady=10)
            return
        for slot in slots:
            row = ctk.CTkFrame(self.list_frame, fg_color="transparent")
            row.pack(fill="x", pady=3, padx=4)
            ctk.CTkLabel(row, text=slot, font=T.FONT_BODY(), text_color=T.TEXT_PRIMARY).pack(side="left")
            ctk.CTkButton(row, text="Remove", width=70, height=26,
                          fg_color=T.BG_SURFACE_2, hover_color=T.ACCENT_RED,
                          text_color=T.TEXT_SECONDARY, font=T.FONT_SMALL(),
                          command=lambda s=slot: self._remove_slot(s)).pack(side="right")

    def _add_slot(self):
        import re
        slot = self.new_slot_var.get().strip()
        if not re.match(r"^\d{2}:\d{2}$", slot):
            W.show_toast(self, "Use 24-hour format, e.g. 13:00", kind="error")
            return
        self.doctor.add_slot(slot)
        self.new_slot_var.set("")
        self._render_slots()
        self.on_change()

    def _remove_slot(self, slot):
        self.doctor.remove_slot(slot)
        self._render_slots()
        self.on_change()
