"""views/appointments.py — Book, cancel, and reschedule appointments."""

import datetime
import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage


class AppointmentsView(ListPage):
    title = "Appointments"
    subtitle = "Book, reschedule, and track patient appointments"
    search_placeholder = "Search by ID, patient, doctor, or status…"
    columns = [
        ("id", "Appt ID", 80),
        ("patient", "Patient", 170),
        ("doctor", "Doctor", 170),
        ("date", "Date", 100),
        ("slot", "Slot", 80),
        ("status", "Status", 110),
    ]

    def header_actions(self):
        return [{"text": "+ Book Appointment", "command": self.add_appointment, "primary": True}]

    def toolbar_actions(self):
        return [("Reschedule", self.reschedule), ("Cancel", self.cancel)]

    def load_rows(self):
        rows = []
        for a in sorted(self.hospital.appointments, key=lambda a: a.appointment_date, reverse=True):
            patient = self.hospital.patients.get(a.patient_id)
            doctor = self.hospital.doctors.get(a.doctor_id)
            rows.append((
                a.appointment_id,
                f"{patient.name} ({a.patient_id})" if patient else a.patient_id,
                f"Dr. {doctor.name} ({a.doctor_id})" if doctor else a.doctor_id,
                a.appointment_date, a.slot, a.status,
            ))
        return rows

    def _patient_options(self):
        return [f"{p.patient_id} - {p.name}" for p in self.hospital.patients.values()] or ["—"]

    def _doctor_options(self):
        return [f"{d.doctor_id} - Dr. {d.name} ({d.specialization})" for d in self.hospital.doctors.values()] or ["—"]

    def add_appointment(self):
        if not self.hospital.patients or not self.hospital.doctors:
            self.toast("Add at least one patient and one doctor first.", kind="warning")
            return
        today = datetime.date.today().strftime("%Y-%m-%d")
        fields = [
            {"key": "patient", "label": "Patient", "kind": "option", "options": self._patient_options()},
            {"key": "doctor", "label": "Doctor", "kind": "option", "options": self._doctor_options()},
            {"key": "date", "label": "Date (YYYY-MM-DD)", "default": today},
            {"key": "slot", "label": "Time Slot (HH:MM)", "placeholder": "e.g. 10:00"},
        ]

        def submit(values):
            pid = values["patient"].split(" - ")[0]
            did = values["doctor"].split(" - ")[0]
            slot = values["slot"].strip()
            doctor = self.hospital.doctors.get(did)
            if not slot:
                return False, "Enter a time slot."
            if doctor and slot not in doctor.available_slots:
                return False, f"Dr. {doctor.name}'s slots: {', '.join(doctor.available_slots)}"
            try:
                appt = self.hospital.book_appointment(pid, did, values["date"], slot)
                self.after_mutation(f"Appointment {appt.appointment_id} booked.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Book Appointment", fields, submit, submit_text="Book")

    def reschedule(self):
        row = self.require_selection()
        if not row:
            return
        appt_id = row[0]
        fields = [
            {"key": "date", "label": "New Date (YYYY-MM-DD)", "default": row[3]},
            {"key": "slot", "label": "New Slot (HH:MM)", "default": row[4]},
        ]

        def submit(values):
            try:
                self.hospital.reschedule_appointment(appt_id, values["date"], values["slot"])
                self.after_mutation(f"Appointment {appt_id} rescheduled.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Reschedule {appt_id}", fields, submit, submit_text="Reschedule")

    def cancel(self):
        row = self.require_selection()
        if not row:
            return
        appt_id = row[0]

        def do_cancel():
            self.hospital.cancel_appointment(appt_id)
            self.after_mutation(f"Appointment {appt_id} cancelled.", kind="info")

        self.confirm(f"Cancel appointment {appt_id}? This cannot be undone.", do_cancel,
                     title="Cancel Appointment")
