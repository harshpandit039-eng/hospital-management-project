"""views/nurses.py — Nurse roster, department assignment, and shift management."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage
import models as m


class NursesView(ListPage):
    title = "Nurses"
    subtitle = "Manage nursing staff, departments, and shifts"
    search_placeholder = "Search by ID, name, or department…"
    columns = [
        ("id", "Nurse ID", 90),
        ("name", "Name", 170),
        ("dept", "Department", 140),
        ("shift", "Shift", 100),
        ("phone", "Phone", 130),
    ]

    def header_actions(self):
        return [{"text": "+ Add Nurse", "command": self.add_nurse, "primary": True}]

    def toolbar_actions(self):
        return [("Edit", self.edit_nurse)]

    def load_rows(self):
        rows = []
        for n in self.hospital.nurses.values():
            rows.append((n.nurse_id, n.name, n.department, n.shift, n.phone))
        return rows

    def add_nurse(self):
        fields = [
            {"key": "name", "label": "Full Name", "placeholder": "e.g. Kavita Nair"},
            {"key": "age", "label": "Age", "placeholder": "e.g. 28"},
            {"key": "gender", "label": "Gender", "kind": "option", "options": ["Male", "Female", "Other"]},
            {"key": "phone", "label": "Phone Number", "placeholder": "e.g. 9876543210"},
            {"key": "department", "label": "Department", "placeholder": "e.g. ICU"},
            {"key": "shift", "label": "Shift", "kind": "option", "options": list(m.Nurse.VALID_SHIFTS)},
        ]

        def submit(values):
            if not values["name"] or not values["department"]:
                return False, "Name and department are required."
            if not values["age"].isdigit():
                return False, "Age must be a number."
            try:
                n = self.hospital.add_nurse(values["name"], int(values["age"]), values["gender"],
                                             values["phone"], values["department"], values["shift"])
                self.after_mutation(f"Nurse {n.name} added ({n.nurse_id}).")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Add New Nurse", fields, submit, submit_text="Add Nurse")

    def edit_nurse(self):
        row = self.require_selection()
        if not row:
            return
        nid = row[0]
        nurse = self.hospital.nurses.get(nid)
        if not nurse:
            return
        fields = [
            {"key": "department", "label": "Department", "default": nurse.department},
            {"key": "shift", "label": "Shift", "kind": "option", "options": list(m.Nurse.VALID_SHIFTS),
             "default": nurse.shift},
        ]

        def submit(values):
            try:
                self.hospital.update_nurse(nid, values["department"] or None, values["shift"] or None)
                self.after_mutation(f"Nurse {nurse.name} updated.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal(f"Edit Nurse — {nurse.name}", fields, submit)
