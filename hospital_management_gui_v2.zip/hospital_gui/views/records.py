"""views/records.py — Patient diagnosis, prescription, and treatment notes."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage


class RecordsView(ListPage):
    title = "Medical Records"
    subtitle = "Diagnoses, prescriptions, and clinical notes per patient"
    search_placeholder = "Search by patient or diagnosis…"
    columns = [
        ("id", "Record ID", 90),
        ("patient", "Patient", 170),
        ("date", "Date", 100),
        ("diagnosis", "Diagnosis", 220),
        ("prescription", "Prescription", 220),
    ]

    def header_actions(self):
        return [{"text": "+ Add Record", "command": self.add_record, "primary": True}]

    def toolbar_actions(self):
        return [("View Full Note", self.view_note)]

    def load_rows(self):
        rows = []
        for r in sorted(self.hospital.medical_records, key=lambda r: r.record_date, reverse=True):
            patient = self.hospital.patients.get(r.patient_id)
            rows.append((r.record_id, f"{patient.name} ({r.patient_id})" if patient else r.patient_id,
                        r.record_date, r.diagnosis, r.prescription))
        return rows

    def on_row_double_click(self, row):
        if row:
            self.view_note()

    def _patient_options(self):
        return [f"{p.patient_id} - {p.name}" for p in self.hospital.patients.values()] or ["—"]

    def add_record(self):
        if not self.hospital.patients:
            self.toast("Register a patient first.", kind="warning")
            return
        fields = [
            {"key": "patient", "label": "Patient", "kind": "option", "options": self._patient_options()},
            {"key": "diagnosis", "label": "Diagnosis", "placeholder": "e.g. Viral Fever"},
            {"key": "prescription", "label": "Prescription", "placeholder": "e.g. Paracetamol 650mg"},
            {"key": "notes", "label": "Notes", "kind": "textarea"},
        ]

        def submit(values):
            pid = values["patient"].split(" - ")[0]
            if not values["diagnosis"] or not values["prescription"]:
                return False, "Diagnosis and prescription are required."
            try:
                rec = self.hospital.add_medical_record(pid, values["diagnosis"],
                                                         values["prescription"], values["notes"])
                self.after_mutation(f"Medical record {rec.record_id} added.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Add Medical Record", fields, submit, submit_text="Save Record")

    def view_note(self):
        row = self.require_selection()
        if not row:
            return
        rid = row[0]
        rec = next((r for r in self.hospital.medical_records if r.record_id == rid), None)
        if not rec:
            return
        patient = self.hospital.patients.get(rec.patient_id)
        sections = [
            ("Record Details", [
                f"Patient: {patient.name if patient else rec.patient_id} ({rec.patient_id})",
                f"Date: {rec.record_date}",
                f"Diagnosis: {rec.diagnosis}",
                f"Prescription: {rec.prescription}",
            ]),
            ("Notes", [rec.notes or "—"]),
        ]
        W.DetailDialog(self.app, f"Medical Record {rid}", sections)
