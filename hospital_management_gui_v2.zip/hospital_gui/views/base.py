"""
views/base.py — Shared scaffolding for every CRUD-style page (patients,
doctors, nurses, etc.): header with actions, optional search bar, a themed
table, and small helpers for opening modals / confirm dialogs / toasts.
Subclasses implement `load_rows()` and wire up their own action buttons.
"""

import customtkinter as ctk

import theme as T
import widgets as W


class ListPage(ctk.CTkFrame):
    """
    columns: list of (key, label, width) passed straight to widgets.DataTable
    """
    columns = []
    title = ""
    subtitle = ""
    searchable = True
    search_placeholder = "Search…"

    def __init__(self, master, hospital, app):
        super().__init__(master, fg_color="transparent")
        self.hospital = hospital
        self.app = app
        self._all_rows_cache = []
        self._build_shell()

    # ── shell layout, override-able pieces ──────────────────
    def header_actions(self):
        """Return a list of action-button specs for the PageHeader. Override me."""
        return []

    def toolbar_actions(self):
        """Return a list of (label, command) for buttons under the search bar
        that act on the current selection (Edit / Delete / View / etc)."""
        return []

    def load_rows(self):
        """Return a list of row-tuples for the table. Override me."""
        return []

    def matches_query(self, row, query):
        """Default search: substring match against any stringified column."""
        query = query.lower()
        return any(query in str(v).lower() for v in row)

    def on_row_select(self, row):
        pass

    def on_row_double_click(self, row):
        pass

    # ── building blocks ──────────────────────────────────────
    def _build_shell(self):
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=28, pady=24)

        header = W.PageHeader(container, self.title, self.subtitle, self.header_actions())
        header.pack(fill="x", pady=(0, 18))

        toolbar = ctk.CTkFrame(container, fg_color="transparent")
        toolbar.pack(fill="x", pady=(0, 12))

        if self.searchable:
            self.search_var = ctk.StringVar()
            search_entry = ctk.CTkEntry(
                toolbar, textvariable=self.search_var, width=320, height=36,
                placeholder_text=self.search_placeholder, fg_color=T.BG_INPUT,
                border_color=T.BORDER, text_color=T.TEXT_PRIMARY, font=T.FONT_BODY(),
            )
            search_entry.pack(side="left")
            self.search_var.trace_add("write", lambda *_: self._apply_filter())

        actions = self.toolbar_actions()
        if actions:
            action_box = ctk.CTkFrame(toolbar, fg_color="transparent")
            action_box.pack(side="right")
            for label, cmd in actions:
                ctk.CTkButton(
                    action_box, text=label, command=cmd, height=36, width=110,
                    fg_color=T.BG_SURFACE_2, hover_color=T.BORDER,
                    text_color=T.TEXT_PRIMARY, font=T.font(12, "bold"),
                    corner_radius=T.RADIUS_SM,
                ).pack(side="left", padx=(8, 0))

        self.row_count_label = ctk.CTkLabel(container, text="", font=T.FONT_SMALL(),
                                             text_color=T.TEXT_MUTED, anchor="w")
        self.row_count_label.pack(fill="x", pady=(0, 6))

        self.table = W.DataTable(
            container, self.columns,
            on_select=self.on_row_select,
            on_double_click=self.on_row_double_click,
            height=16,
        )
        self.table.pack(fill="both", expand=True)

        self.refresh()

    # ── data flow ────────────────────────────────────────────
    def refresh(self):
        self._all_rows_cache = self.load_rows()
        self._apply_filter()

    def _apply_filter(self):
        query = self.search_var.get().strip() if self.searchable else ""
        if query:
            rows = [r for r in self._all_rows_cache if self.matches_query(r, query)]
        else:
            rows = self._all_rows_cache
        self.table.load_rows(rows)
        total = len(self._all_rows_cache)
        shown = len(rows)
        if query:
            self.row_count_label.configure(text=f"Showing {shown} of {total} records")
        else:
            self.row_count_label.configure(text=f"{total} record(s)")

    # ── helpers for subclasses ───────────────────────────────
    def require_selection(self):
        row = self.table.get_selected()
        if not row:
            W.show_toast(self, "Select a row first.", kind="warning")
            return None
        return row

    def open_modal(self, title, fields, on_submit, submit_text="Save"):
        W.ModalForm(self.app, title, fields, on_submit, submit_text=submit_text)

    def confirm(self, message, on_confirm, title="Please Confirm"):
        W.ConfirmDialog(self.app, message, on_confirm, title=title)

    def toast(self, message, kind="success"):
        W.show_toast(self, message, kind=kind)

    def after_mutation(self, message=None, kind="success"):
        self.refresh()
        if message:
            self.toast(message, kind=kind)
        if hasattr(self.app, "refresh_dashboard_if_active"):
            self.app.refresh_dashboard_if_active()
