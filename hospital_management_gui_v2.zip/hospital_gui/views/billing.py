"""views/billing.py — Generate and review patient bills."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage


class BillingView(ListPage):
    title = "Billing"
    subtitle = "Generate consolidated bills and review past receipts"
    search_placeholder = "Search by patient or bill ID…"
    columns = [
        ("id", "Bill ID", 80),
        ("patient", "Patient", 170),
        ("consult", "Consultation", 100),
        ("med", "Medicine", 90),
        ("lab", "Lab", 90),
        ("total", "Total", 100),
        ("date", "Generated On", 150),
    ]

    def header_actions(self):
        return [{"text": "+ Generate Bill", "command": self.add_bill, "primary": True}]

    def toolbar_actions(self):
        return [("View Receipt", self.view_receipt)]

    def load_rows(self):
        rows = []
        for b in sorted(self.hospital.bills, key=lambda b: b.generated_on, reverse=True):
            patient = self.hospital.patients.get(b.patient_id)
            rows.append((
                b.bill_id, f"{patient.name} ({b.patient_id})" if patient else b.patient_id,
                f"₹{b.consultation_charge:,.0f}", f"₹{b.medicine_charge:,.0f}",
                f"₹{b.lab_charge:,.0f}", f"₹{b.total_amount:,.2f}", b.generated_on,
            ))
        return rows

    def on_row_double_click(self, row):
        if row:
            self.view_receipt()

    def _patient_options(self):
        return [f"{p.patient_id} - {p.name}" for p in self.hospital.patients.values()] or ["—"]

    def add_bill(self):
        if not self.hospital.patients:
            self.toast("Register a patient first.", kind="warning")
            return
        fields = [
            {"key": "patient", "label": "Patient", "kind": "option", "options": self._patient_options()},
            {"key": "consultation", "label": "Consultation Charge (₹)", "default": "0"},
            {"key": "medicine", "label": "Medicine Charge (₹)", "default": "0"},
            {"key": "lab", "label": "Lab Charge (₹)", "default": "0"},
        ]

        def submit(values):
            pid = values["patient"].split(" - ")[0]
            try:
                consult = float(values["consultation"] or 0)
                med = float(values["medicine"] or 0)
                lab = float(values["lab"] or 0)
            except ValueError:
                return False, "Charges must be numbers."
            if consult < 0 or med < 0 or lab < 0:
                return False, "Charges cannot be negative."
            try:
                bill = self.hospital.generate_bill(pid, consult, med, lab)
                self.after_mutation(f"Bill {bill.bill_id} generated — ₹{bill.total_amount:,.2f}.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Generate Bill", fields, submit, submit_text="Generate")

    def view_receipt(self):
        row = self.require_selection()
        if not row:
            return
        bid = row[0]
        bill = next((b for b in self.hospital.bills if b.bill_id == bid), None)
        if not bill:
            return
        patient = self.hospital.patients.get(bill.patient_id)
        sections = [
            ("Hospital Bill Receipt", [
                f"Patient: {patient.name if patient else bill.patient_id} ({bill.patient_id})",
                f"Generated On: {bill.generated_on}",
                f"Consultation: ₹{bill.consultation_charge:,.2f}",
                f"Medicine: ₹{bill.medicine_charge:,.2f}",
                f"Laboratory: ₹{bill.lab_charge:,.2f}",
                f"TOTAL: ₹{bill.total_amount:,.2f}",
            ]),
        ]
        W.DetailDialog(self.app, f"Receipt — {bid}", sections)
