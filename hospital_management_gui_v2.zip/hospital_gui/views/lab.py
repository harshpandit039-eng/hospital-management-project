"""views/lab.py — Laboratory test reports per patient."""

import customtkinter as ctk

import theme as T
import widgets as W
from views.base import ListPage


class LabView(ListPage):
    title = "Lab Reports"
    subtitle = "Generate and review laboratory test results"
    search_placeholder = "Search by patient or test name…"
    columns = [
        ("id", "Report ID", 90),
        ("patient", "Patient", 170),
        ("test", "Test Name", 200),
        ("result", "Result", 220),
        ("date", "Date", 100),
    ]

    def header_actions(self):
        return [{"text": "+ Generate Report", "command": self.add_report, "primary": True}]

    def load_rows(self):
        rows = []
        for r in sorted(self.hospital.lab_reports, key=lambda r: r.report_date, reverse=True):
            patient = self.hospital.patients.get(r.patient_id)
            rows.append((r.report_id, f"{patient.name} ({r.patient_id})" if patient else r.patient_id,
                        r.test_name, r.result, r.report_date))
        return rows

    def _patient_options(self):
        return [f"{p.patient_id} - {p.name}" for p in self.hospital.patients.values()] or ["—"]

    def add_report(self):
        if not self.hospital.patients:
            self.toast("Register a patient first.", kind="warning")
            return
        fields = [
            {"key": "patient", "label": "Patient", "kind": "option", "options": self._patient_options()},
            {"key": "test_name", "label": "Test Name", "placeholder": "e.g. Complete Blood Count"},
            {"key": "result", "label": "Result", "kind": "textarea"},
        ]

        def submit(values):
            pid = values["patient"].split(" - ")[0]
            if not values["test_name"] or not values["result"]:
                return False, "Test name and result are required."
            try:
                rep = self.hospital.generate_lab_report(pid, values["test_name"], values["result"])
                self.after_mutation(f"Lab report {rep.report_id} generated.")
                return True, None
            except Exception as e:
                return False, str(e)

        self.open_modal("Generate Lab Report", fields, submit, submit_text="Generate")
