"""
views/dashboard.py — Landing page: KPI stat cards, embedded charts,
hospital rules, and a live "recent activity" feed sourced from the
model layer's ACTIVITY_LOG.
"""

import datetime
import customtkinter as ctk

import theme as T
import widgets as W
import charts


class DashboardView(ctk.CTkFrame):
    def __init__(self, master, hospital, app):
        super().__init__(master, fg_color="transparent")
        self.hospital = hospital
        self.app = app
        self._build()

    # ── layout ───────────────────────────────────────────
    def _build(self):
        # Header row: title + ECG strip
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=28, pady=(24, 14))

        left = ctk.CTkFrame(header, fg_color="transparent")
        left.pack(side="left", fill="y")
        ctk.CTkLabel(left, text=f"Welcome back — {self.hospital.get_hospital_name()}",
                     font=T.FONT_H1(), text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w")
        ctk.CTkLabel(left, text=datetime.datetime.now().strftime("%A, %d %B %Y"),
                     font=T.FONT_BODY(), text_color=T.TEXT_SECONDARY, anchor="w").pack(
            anchor="w", pady=(2, 0))

        ecg_card = ctk.CTkFrame(header, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                 border_width=1, border_color=T.BORDER_SOFT)
        ecg_card.pack(side="right")
        ctk.CTkLabel(ecg_card, text="LIVE SYSTEM STATUS", font=T.font(10, "bold"),
                     text_color=T.TEXT_MUTED).pack(anchor="w", padx=16, pady=(10, 0))
        self.ecg = W.ECGStrip(ecg_card, width=380, height=64)
        self.ecg.pack(padx=12, pady=(0, 10))

        # Scrollable body
        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=28, pady=(0, 20))

        # Stat cards row
        self.stat_row = ctk.CTkFrame(body, fg_color="transparent")
        self.stat_row.pack(fill="x", pady=(0, 18))
        for i in range(4):
            self.stat_row.grid_columnconfigure(i, weight=1, uniform="stat")

        self.card_patients = W.StatCard(self.stat_row, "🧑‍🤝‍🧑", "Total Patients", accent=T.ACCENT_BLUE)
        self.card_doctors = W.StatCard(self.stat_row, "🩺", "Active Doctors", accent=T.ACCENT_TEAL)
        self.card_today = W.StatCard(self.stat_row, "📅", "Appointments Today", accent=T.ACCENT_GOLD)
        self.card_revenue = W.StatCard(self.stat_row, "💰", "Total Revenue", accent=T.ACCENT_GREEN)
        for i, card in enumerate([self.card_patients, self.card_doctors, self.card_today, self.card_revenue]):
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))

        # Charts grid (2x2) + activity feed on the right
        mid = ctk.CTkFrame(body, fg_color="transparent")
        mid.pack(fill="both", expand=True)
        mid.grid_columnconfigure(0, weight=3)
        mid.grid_columnconfigure(1, weight=2)

        charts_col = ctk.CTkFrame(mid, fg_color="transparent")
        charts_col.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        charts_col.grid_columnconfigure(0, weight=1)
        charts_col.grid_columnconfigure(1, weight=1)

        self.chart_frame_status = ctk.CTkFrame(charts_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                                border_width=1, border_color=T.BORDER_SOFT)
        self.chart_frame_status.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(0, 14))

        self.chart_frame_revenue = ctk.CTkFrame(charts_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                                 border_width=1, border_color=T.BORDER_SOFT)
        self.chart_frame_revenue.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 14))

        self.chart_frame_doctors = ctk.CTkFrame(charts_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                                 border_width=1, border_color=T.BORDER_SOFT)
        self.chart_frame_doctors.grid(row=1, column=0, sticky="nsew", padx=(0, 7))

        self.chart_frame_stock = ctk.CTkFrame(charts_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                               border_width=1, border_color=T.BORDER_SOFT)
        self.chart_frame_stock.grid(row=1, column=1, sticky="nsew", padx=(7, 0))

        # Right column: activity feed + hospital rules
        right_col = ctk.CTkFrame(mid, fg_color="transparent")
        right_col.grid(row=0, column=1, sticky="nsew")

        activity_card = ctk.CTkFrame(right_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                      border_width=1, border_color=T.BORDER_SOFT)
        activity_card.pack(fill="both", expand=True, pady=(0, 14))
        ctk.CTkLabel(activity_card, text="Recent Activity", font=T.FONT_H3(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w", padx=18, pady=(16, 4))
        self.activity_list = ctk.CTkScrollableFrame(activity_card, fg_color="transparent", height=230)
        self.activity_list.pack(fill="both", expand=True, padx=10, pady=(0, 12))

        rules_card = ctk.CTkFrame(right_col, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                                   border_width=1, border_color=T.BORDER_SOFT)
        rules_card.pack(fill="x")
        ctk.CTkLabel(rules_card, text="Hospital Policies", font=T.FONT_H3(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w", padx=18, pady=(16, 6))
        for rule in self.hospital.HOSPITAL_RULES:
            row = ctk.CTkFrame(rules_card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=3)
            ctk.CTkLabel(row, text="•", text_color=T.ACCENT_RED, font=T.FONT_BODY()).pack(side="left")
            ctk.CTkLabel(row, text=rule, font=T.FONT_SMALL(), text_color=T.TEXT_SECONDARY,
                         anchor="w", justify="left", wraplength=270).pack(side="left", padx=(6, 0), fill="x")
        ctk.CTkFrame(rules_card, height=12, fg_color="transparent").pack()

        self.refresh()

    # ── data refresh ─────────────────────────────────────
    def refresh(self):
        h = self.hospital
        today = datetime.date.today().strftime("%Y-%m-%d")

        self.card_patients.set_value(len(h.patients))
        self.card_doctors.set_value(len(h.doctors))
        today_appts = [a for a in h.appointments if a.appointment_date == today and a.status != "Cancelled"]
        self.card_today.set_value(len(today_appts))
        total_revenue = sum(b.total_amount for b in h.bills)
        self.card_revenue.set_value(f"₹{total_revenue:,.0f}")

        self._render_status_chart()
        self._render_revenue_chart()
        self._render_doctors_chart()
        self._render_stock_chart()
        self._render_activity()

    def _clear(self, frame):
        for w in frame.winfo_children():
            w.destroy()

    def _render_status_chart(self):
        self._clear(self.chart_frame_status)
        statuses = ["Scheduled", "Completed", "Cancelled", "Rescheduled"]
        counts = [sum(1 for a in self.hospital.appointments if a.status == s) for s in statuses]
        colors = [T.STATUS_COLORS[s] for s in statuses]
        widget = charts.donut_chart(self.chart_frame_status, statuses, counts, colors,
                                     title="Appointments by Status")
        widget.pack(fill="both", expand=True, padx=8, pady=8)

    def _render_revenue_chart(self):
        self._clear(self.chart_frame_revenue)
        by_day = {}
        for b in self.hospital.bills:
            day = b.generated_on.split(" ")[0][5:]  # MM-DD
            by_day[day] = by_day.get(day, 0) + b.total_amount
        days = sorted(by_day.keys())
        values = [by_day[d] for d in days]
        widget = charts.line_chart(self.chart_frame_revenue, days, values,
                                    title="Revenue Trend (₹)")
        widget.pack(fill="both", expand=True, padx=8, pady=8)

    def _render_doctors_chart(self):
        self._clear(self.chart_frame_doctors)
        spec_counts = {}
        for d in self.hospital.doctors.values():
            spec_counts[d.specialization] = spec_counts.get(d.specialization, 0) + 1
        labels = list(spec_counts.keys())
        values = list(spec_counts.values())
        widget = charts.bar_chart(self.chart_frame_doctors, labels, values, color=T.ACCENT_BLUE,
                                   title="Doctors by Specialization")
        widget.pack(fill="both", expand=True, padx=8, pady=8)

    def _render_stock_chart(self):
        self._clear(self.chart_frame_stock)
        meds = sorted(self.hospital.medicines.values(), key=lambda m: m.stock)[:6]
        labels = [m.medicine_name[:16] for m in meds]
        values = [m.stock for m in meds]
        widget = charts.bar_chart(self.chart_frame_stock, labels, values, color=T.ACCENT_GOLD,
                                   title="Lowest Stock Levels", horizontal=True)
        widget.pack(fill="both", expand=True, padx=8, pady=8)

    def _render_activity(self):
        import models as m
        for w in self.activity_list.winfo_children():
            w.destroy()
        entries = list(reversed(m.ACTIVITY_LOG[-12:]))
        if not entries:
            ctk.CTkLabel(self.activity_list, text="No activity yet — actions you take will appear here.",
                         font=T.FONT_SMALL(), text_color=T.TEXT_MUTED, wraplength=260,
                         justify="left").pack(anchor="w", padx=8, pady=8)
            return
        for entry in entries:
            row = ctk.CTkFrame(self.activity_list, fg_color="transparent")
            row.pack(fill="x", pady=4, padx=4)
            dot_color = T.ACCENT_GREEN if entry["status"] == "SUCCESS" else T.ACCENT_RED
            dot = ctk.CTkFrame(row, width=8, height=8, corner_radius=4, fg_color=dot_color)
            dot.pack(side="left", padx=(2, 10), pady=4)
            dot.pack_propagate(False)
            text_box = ctk.CTkFrame(row, fg_color="transparent")
            text_box.pack(side="left", fill="x", expand=True)
            label = entry["action"].replace("_", " ").title()
            ctk.CTkLabel(text_box, text=label, font=T.font(12, "bold"),
                         text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w")
            ctk.CTkLabel(text_box, text=entry["time"], font=T.FONT_SMALL(),
                         text_color=T.TEXT_MUTED, anchor="w").pack(anchor="w")
