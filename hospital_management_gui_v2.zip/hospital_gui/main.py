"""
main.py — Smart City Hospital Management System (Desktop Edition)
Entry point. Wires the sidebar navigation to each module view and owns
the single shared Hospital instance (the model/business-logic layer).

Run with:  python3 main.py
"""

import os
import sys
import customtkinter as ctk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import theme as T
import widgets as W
import models as m
import seed_data
from views.dashboard import DashboardView
from views.patients import PatientsView
from views.doctors import DoctorsView
from views.nurses import NursesView
from views.appointments import AppointmentsView
from views.pharmacy import PharmacyView
from views.records import RecordsView
from views.lab import LabView
from views.billing import BillingView
from views.reports import ReportsView

ctk.set_appearance_mode("dark")

PAGE_CLASSES = {
    "dashboard": DashboardView,
    "patients": PatientsView,
    "doctors": DoctorsView,
    "nurses": NursesView,
    "appointments": AppointmentsView,
    "pharmacy": PharmacyView,
    "records": RecordsView,
    "lab": LabView,
    "billing": BillingView,
    "reports": ReportsView,
}


class HospitalApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Smart City Hospital — Management System")
        self.geometry("1440x900")
        self.minsize(1180, 720)
        self.configure(fg_color=T.BG_APP)

        self.hospital = m.Hospital()
        self._bootstrap_data()

        self.pages = {}
        self.current_key = None

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True)

        self.sidebar = W.Sidebar(body, T.NAV_ITEMS, on_select=self.show_page)
        self.sidebar.pack(side="left", fill="y")

        self.content = ctk.CTkFrame(body, fg_color=T.BG_APP)
        self.content.pack(side="left", fill="both", expand=True)

        self.show_page("dashboard")
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _bootstrap_data(self):
        """Load saved data if present; otherwise seed demo data for a populated first run."""
        try:
            has_save_files = os.path.exists(m.FILES["patients"])
        except Exception:
            has_save_files = False

        if has_save_files:
            self.hospital.load_data()
        else:
            seed_data.seed(self.hospital)

    def show_page(self, key):
        for k, page in self.pages.items():
            page.pack_forget()

        if key not in self.pages:
            page_cls = PAGE_CLASSES[key]
            self.pages[key] = page_cls(self.content, self.hospital, self)

        page = self.pages[key]
        page.pack(fill="both", expand=True)
        if hasattr(page, "refresh"):
            page.refresh()
        self.current_key = key
        self.sidebar.set_active(key)

    def refresh_all(self):
        for page in self.pages.values():
            if hasattr(page, "refresh"):
                page.refresh()

    def refresh_dashboard_if_active(self):
        if "dashboard" in self.pages:
            self.pages["dashboard"].refresh()

    def _on_close(self):
        self.destroy()


if __name__ == "__main__":
    app = HospitalApp()
    app.mainloop()
