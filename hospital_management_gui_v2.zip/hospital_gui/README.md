# Smart City Hospital Management System — Desktop GUI v2.0

A full-featured **Python desktop application** built with **CustomTkinter** and **Matplotlib**,
demonstrating advanced OOP, clean MVC architecture, and production-quality UI design.

This is the GUI evolution of a hospital management system that showcases:

---

## 📸 Features

| Module | What It Does |
|--------|-------------|
| 🏠 Dashboard | Live KPI cards (patients, doctors, revenue), ECG animation, 4 embedded charts, activity feed |
| 🧑‍🤝‍🧑 Patients | Register, search (ID/name), edit, full medical history viewer |
| 🩺 Doctors | Add/edit doctors, manage time slots, sorted fee listing |
| 👩‍⚕️ Nurses | Add/edit nurses, department + shift management |
| 📅 Appointments | Book with slot conflict detection, reschedule, cancel |
| 💊 Pharmacy | Inventory tracking, add stock, dispense, expiry watchlist |
| 📋 Medical Records | Diagnoses + prescriptions with full note viewer |
| 🧪 Lab Reports | Generate and browse test results per patient |
| 🧾 Billing | Generate bills, view itemized receipts |
| 📊 Reports & Data | Hospital statistics, one-click CSV exports, JSON save/load |

---

## 🏗️ Architecture — OOP Concepts Used

| Concept | Where Used |
|---------|-----------|
| Abstract Base Class (`ABC`) | `Person` → base for `Patient`, `Doctor`, `Nurse` |
| Inheritance + Polymorphism | `display_details()` overridden in each subclass |
| Encapsulation | Private attributes (`__name`) with `@property` getters/setters |
| Composition | `Hospital` owns all other objects |
| Decorator Factory | `@log_action(name)` wraps register/book/bill methods |
| Static & Class Methods | `Person.generate_id()`, `Hospital.get_version()` |
| Magic Methods | `__str__`, `__repr__` on every model class |
| Generators | CSV export uses `yield`-based generators |
| Lambda Functions | `sort_doctors_by_fee`, `sort_medicines_by_price`, `sort_appointments_by_date` |
| Recursion | `search_patient_recursive()` |
| List/Dict/Set | All four data structures used across `Hospital` |
| JSON File Handling | `save_data()` / `load_data()` with full error handling |
| CSV Export | Three reports via `csv.DictWriter` + custom generators |
| Custom Exceptions | 10 domain-specific exception classes |
| MVC Pattern | `models.py` (M) · `views/` (V) · `main.py` (C) |

---

## 🖥️ Tech Stack

- **Python 3.10+**
- **CustomTkinter 5.2** — modern themed widgets
- **Matplotlib** — embedded bar, donut, and line charts
- **tkinter/ttk** — native `Treeview` for data tables
- JSON for persistence · CSV for reporting

---

## 🚀 Running the App

```bash
# Install dependencies
pip install customtkinter matplotlib

# Run
python main.py
```

On **first launch**, demo data is automatically seeded (14 patients, 6 doctors, 8 nurses,
18 appointments, 12 medicines, 18 bills). After saving, your data persists in `data/`.

---

## 📁 Project Structure

```
hospital_gui/
├── main.py              # App entry point + navigation controller
├── models.py            # All OOP business logic (Hospital, Patient, Doctor, …)
├── theme.py             # Design tokens: colors, fonts, spacing
├── widgets.py           # Reusable UI components (Sidebar, StatCard, DataTable, …)
├── charts.py            # Matplotlib chart helpers
├── seed_data.py         # Realistic demo data generator
├── views/
│   ├── base.py          # ListPage — shared CRUD page scaffolding
│   ├── dashboard.py     # KPI dashboard with embedded charts
│   ├── patients.py
│   ├── doctors.py
│   ├── nurses.py
│   ├── appointments.py
│   ├── pharmacy.py
│   ├── records.py
│   ├── lab.py
│   ├── billing.py
│   └── reports.py
├── data/                # JSON persistence (auto-created)
└── reports/             # CSV exports (auto-created)
```

---

## 👨‍💻 Developer

**Harshit** | B.Sc. Mathematics & Statistics  
GitHub: [harshpandit039-eng](https://github.com/harshpandit039-eng)
