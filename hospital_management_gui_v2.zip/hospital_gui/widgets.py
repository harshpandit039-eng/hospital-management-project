"""
widgets.py — Reusable UI building blocks shared across every view:
  - Sidebar / NavButton
  - StatCard (dashboard KPI tiles)
  - DataTable (themed ttk.Treeview wrapper with search + scrollbars)
  - ModalForm (generic add/edit dialog built from a field spec)
  - ConfirmDialog
  - Toast (transient success/error notification)
  - PageHeader (title + action buttons row)
"""

import tkinter as tk
from tkinter import ttk
import customtkinter as ctk

import theme as T


# ============================================================
#  SIDEBAR
# ============================================================

class NavButton(ctk.CTkButton):
    """A single sidebar navigation entry that tracks active/inactive state."""

    def __init__(self, master, text, command):
        super().__init__(
            master,
            text=text,
            anchor="w",
            command=command,
            corner_radius=T.RADIUS_SM,
            fg_color="transparent",
            hover_color=T.BG_SIDEBAR_HI,
            text_color=T.TEXT_SECONDARY,
            font=T.FONT_BODY(),
            height=40,
        )

    def set_active(self, active):
        if active:
            self.configure(fg_color=T.BG_SIDEBAR_HI, text_color=T.TEXT_PRIMARY,
                            font=T.font(13, "bold"))
        else:
            self.configure(fg_color="transparent", text_color=T.TEXT_SECONDARY,
                            font=T.FONT_BODY())


class Sidebar(ctk.CTkFrame):
    """Left navigation rail with hospital branding and a live clock."""

    def __init__(self, master, nav_items, on_select):
        super().__init__(master, width=T.SIDEBAR_W, corner_radius=0, fg_color=T.BG_SIDEBAR)
        self.on_select = on_select
        self.buttons = {}
        self.grid_propagate(False)

        # Branding block
        brand = ctk.CTkFrame(self, fg_color="transparent")
        brand.pack(fill="x", padx=20, pady=(26, 18))
        ctk.CTkLabel(brand, text="✚", font=T.font(22, "bold"),
                     text_color=T.ACCENT_RED).pack(side="left", padx=(0, 8))
        title_box = ctk.CTkFrame(brand, fg_color="transparent")
        title_box.pack(side="left")
        ctk.CTkLabel(title_box, text="Smart City", font=T.FONT_LOGO(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w")
        ctk.CTkLabel(title_box, text="HOSPITAL SYSTEM", font=T.font(10, "bold"),
                     text_color=T.TEXT_MUTED, anchor="w").pack(anchor="w")

        ctk.CTkFrame(self, height=1, fg_color=T.BORDER_SOFT).pack(fill="x", padx=16, pady=(0, 12))

        nav_scroll = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                             scrollbar_button_color=T.BG_SIDEBAR,
                                             scrollbar_button_hover_color=T.BG_SIDEBAR)
        nav_scroll.pack(fill="both", expand=True, padx=12)

        for key, label in nav_items:
            btn = NavButton(nav_scroll, label, command=lambda k=key: self._select(k))
            btn.pack(fill="x", pady=3)
            self.buttons[key] = btn

        # Footer
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=16, pady=16, side="bottom")
        ctk.CTkFrame(footer, height=1, fg_color=T.BORDER_SOFT).pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(footer, text="v2.0 · Desktop Edition", font=T.FONT_SMALL(),
                     text_color=T.TEXT_MUTED).pack(anchor="w")

    def _select(self, key):
        for k, btn in self.buttons.items():
            btn.set_active(k == key)
        self.on_select(key)

    def set_active(self, key):
        for k, btn in self.buttons.items():
            btn.set_active(k == key)


# ============================================================
#  STAT CARD
# ============================================================

class StatCard(ctk.CTkFrame):
    """A KPI tile used on the dashboard: icon, big number, label, optional delta."""

    def __init__(self, master, icon, label, value="0", accent=None, sub=None):
        accent = accent or T.ACCENT_BLUE
        super().__init__(master, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                          border_width=1, border_color=T.BORDER_SOFT)

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=18, pady=(16, 0))
        chip = ctk.CTkFrame(top, width=36, height=36, corner_radius=10,
                             fg_color=self._tint(accent))
        chip.pack(side="left")
        chip.pack_propagate(False)
        ctk.CTkLabel(chip, text=icon, font=T.font(16), text_color=accent).place(
            relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(self, text=label, font=T.FONT_SMALL(),
                     text_color=T.TEXT_SECONDARY, anchor="w").pack(
            fill="x", padx=18, pady=(12, 0))

        self.value_label = ctk.CTkLabel(self, text=value, font=T.FONT_STAT(),
                                         text_color=T.TEXT_PRIMARY, anchor="w")
        self.value_label.pack(fill="x", padx=18, pady=(2, 4))

        if sub:
            ctk.CTkLabel(self, text=sub, font=T.FONT_SMALL(),
                         text_color=accent, anchor="w").pack(
                fill="x", padx=18, pady=(0, 14))
        else:
            ctk.CTkFrame(self, height=10, fg_color="transparent").pack()

    @staticmethod
    def _tint(hex_color):
        # cheap "20% alpha over dark bg" approximation for the icon chip
        hex_color = hex_color.lstrip("#")
        r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        bg = (0x10, 0x1C, 0x30)
        mix = tuple(int(bg[i] * 0.7 + (r, g, b)[i] * 0.3) for i in range(3))
        return "#%02x%02x%02x" % mix

    def set_value(self, value):
        self.value_label.configure(text=str(value))


# ============================================================
#  PAGE HEADER
# ============================================================

class PageHeader(ctk.CTkFrame):
    """Title + subtitle on the left, action buttons on the right."""

    def __init__(self, master, title, subtitle=None, actions=None):
        super().__init__(master, fg_color="transparent")
        text_box = ctk.CTkFrame(self, fg_color="transparent")
        text_box.pack(side="left", fill="y")
        ctk.CTkLabel(text_box, text=title, font=T.FONT_H1(),
                     text_color=T.TEXT_PRIMARY, anchor="w").pack(anchor="w")
        if subtitle:
            ctk.CTkLabel(text_box, text=subtitle, font=T.FONT_BODY(),
                         text_color=T.TEXT_SECONDARY, anchor="w").pack(anchor="w", pady=(2, 0))

        if actions:
            action_box = ctk.CTkFrame(self, fg_color="transparent")
            action_box.pack(side="right")
            for spec in actions:
                primary = spec.get("primary", False)
                btn = ctk.CTkButton(
                    action_box,
                    text=spec["text"],
                    command=spec["command"],
                    corner_radius=T.RADIUS_SM,
                    height=38,
                    fg_color=T.ACCENT_RED if primary else T.BG_SURFACE_2,
                    hover_color=T.ACCENT_RED_HI if primary else T.BORDER,
                    text_color="#FFFFFF" if primary else T.TEXT_PRIMARY,
                    border_width=0 if primary else 1,
                    border_color=T.BORDER,
                    font=T.font(13, "bold"),
                )
                btn.pack(side="left", padx=(8, 0))


# ============================================================
#  DATA TABLE (ttk.Treeview wrapper)
# ============================================================

class DataTable(ctk.CTkFrame):
    """
    Themed table used for every list view (patients, doctors, etc).
    columns: list of (key, label, width)
    """

    def __init__(self, master, columns, on_select=None, on_double_click=None, height=18):
        super().__init__(master, corner_radius=T.RADIUS, fg_color=T.BG_SURFACE,
                          border_width=1, border_color=T.BORDER_SOFT)
        self.columns = columns
        self.on_select = on_select

        style = ttk.Style()
        T.style_treeview(style)

        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=2, pady=2)

        col_keys = [c[0] for c in columns]
        self.tree = ttk.Treeview(
            container, columns=col_keys, show="headings",
            style="Hospital.Treeview", height=height, selectmode="browse",
        )
        for key, label, width in columns:
            self.tree.heading(key, text=label)
            self.tree.column(key, width=width, anchor="w")

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y", pady=10)

        if on_select:
            self.tree.bind("<<TreeviewSelect>>", lambda e: on_select(self.get_selected()))
        if on_double_click:
            self.tree.bind("<Double-1>", lambda e: on_double_click(self.get_selected()))

    def load_rows(self, rows):
        """rows: list of tuples matching column order. First element should be the row id/key."""
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            self.tree.insert("", "end", iid=str(row[0]), values=row)

    def clear(self):
        self.tree.delete(*self.tree.get_children())

    def get_selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.item(sel[0], "values")

    def get_selected_id(self):
        sel = self.tree.selection()
        return sel[0] if sel else None

    def row_count(self):
        return len(self.tree.get_children())


# ============================================================
#  MODAL FORM
# ============================================================

class ModalForm(ctk.CTkToplevel):
    """
    Generic add/edit modal built from a field spec.
    fields: list of dicts:
      {key, label, kind: "entry"|"option"|"textarea", options: [...], default: ...}
    on_submit(values_dict) should return (True, message) or (False, error_message).
    """

    def __init__(self, master, title, fields, on_submit, submit_text="Save"):
        super().__init__(master)
        self.title(title)
        self.geometry("440x" + str(min(140 + len(fields) * 64, 680)))
        self.configure(fg_color=T.BG_APP)
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.grab_set()

        self.fields = fields
        self.on_submit = on_submit
        self.inputs = {}

        ctk.CTkLabel(self, text=title, font=T.FONT_H2(), text_color=T.TEXT_PRIMARY).pack(
            anchor="w", padx=24, pady=(22, 14))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24)

        for f in fields:
            ctk.CTkLabel(scroll, text=f["label"], font=T.FONT_SMALL(),
                         text_color=T.TEXT_SECONDARY, anchor="w").pack(fill="x", pady=(8, 4))
            kind = f.get("kind", "entry")
            if kind == "option":
                var = ctk.StringVar(value=f.get("default", f["options"][0]))
                widget = ctk.CTkOptionMenu(
                    scroll, values=f["options"], variable=var,
                    fg_color=T.BG_INPUT, button_color=T.BG_SURFACE_2,
                    button_hover_color=T.BORDER, text_color=T.TEXT_PRIMARY,
                    dropdown_fg_color=T.BG_SURFACE_2, font=T.FONT_BODY(),
                )
                widget.pack(fill="x")
                self.inputs[f["key"]] = var
            elif kind == "textarea":
                widget = ctk.CTkTextbox(scroll, height=70, fg_color=T.BG_INPUT,
                                         text_color=T.TEXT_PRIMARY, font=T.FONT_BODY())
                if f.get("default"):
                    widget.insert("1.0", str(f["default"]))
                widget.pack(fill="x")
                self.inputs[f["key"]] = widget
            else:
                var = ctk.StringVar(value=f.get("default", ""))
                widget = ctk.CTkEntry(scroll, textvariable=var, fg_color=T.BG_INPUT,
                                       border_color=T.BORDER, text_color=T.TEXT_PRIMARY,
                                       placeholder_text=f.get("placeholder", ""),
                                       font=T.FONT_BODY(), height=36)
                widget.pack(fill="x")
                self.inputs[f["key"]] = var

        self.error_label = ctk.CTkLabel(self, text="", font=T.FONT_SMALL(),
                                         text_color=T.ACCENT_RED)
        self.error_label.pack(padx=24, pady=(8, 0), anchor="w")

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=24, pady=18, side="bottom")
        ctk.CTkButton(btn_row, text="Cancel", command=self.destroy, height=38,
                      fg_color=T.BG_SURFACE_2, hover_color=T.BORDER,
                      text_color=T.TEXT_PRIMARY, font=T.font(13, "bold")).pack(
            side="right", padx=(8, 0))
        ctk.CTkButton(btn_row, text=submit_text, command=self._submit, height=38,
                      fg_color=T.ACCENT_RED, hover_color=T.ACCENT_RED_HI,
                      text_color="#FFFFFF", font=T.font(13, "bold")).pack(side="right")

        self.bind("<Return>", lambda e: self._submit())
        self.after(50, lambda: self.focus_force())

    def _collect(self):
        values = {}
        for f in self.fields:
            key = f["key"]
            widget = self.inputs[key]
            if f.get("kind") == "textarea":
                values[key] = widget.get("1.0", "end").strip()
            else:
                values[key] = widget.get().strip()
        return values

    def _submit(self):
        values = self._collect()
        ok, message = self.on_submit(values)
        if ok:
            self.destroy()
            if message:
                show_toast(self.master, message, kind="success")
        else:
            self.error_label.configure(text=f"⚠ {message}")


# ============================================================
#  CONFIRM DIALOG
# ============================================================

class ConfirmDialog(ctk.CTkToplevel):
    def __init__(self, master, message, on_confirm, title="Confirm"):
        super().__init__(master)
        self.title(title)
        self.geometry("380x170")
        self.configure(fg_color=T.BG_APP)
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.grab_set()

        ctk.CTkLabel(self, text=title, font=T.FONT_H3(), text_color=T.TEXT_PRIMARY).pack(
            anchor="w", padx=22, pady=(20, 6))
        ctk.CTkLabel(self, text=message, font=T.FONT_BODY(), text_color=T.TEXT_SECONDARY,
                     wraplength=330, justify="left", anchor="w").pack(
            anchor="w", padx=22, fill="x")

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=22, pady=20, side="bottom")

        def confirm():
            self.destroy()
            on_confirm()

        ctk.CTkButton(btn_row, text="Cancel", command=self.destroy, height=36,
                      fg_color=T.BG_SURFACE_2, hover_color=T.BORDER,
                      text_color=T.TEXT_PRIMARY).pack(side="right", padx=(8, 0))
        ctk.CTkButton(btn_row, text="Yes, Continue", command=confirm, height=36,
                      fg_color=T.ACCENT_RED, hover_color=T.ACCENT_RED_HI,
                      text_color="#FFFFFF").pack(side="right")


# ============================================================
#  TOAST NOTIFICATION
# ============================================================

def show_toast(parent_widget, message, kind="success", duration=2200):
    """Transient bottom-right notification. parent_widget: any widget inside the main window."""
    root = parent_widget.winfo_toplevel()
    color = {
        "success": T.ACCENT_GREEN,
        "error": T.ACCENT_RED,
        "info": T.ACCENT_BLUE,
        "warning": T.ACCENT_GOLD,
    }.get(kind, T.ACCENT_BLUE)
    icon = {"success": "✓", "error": "✕", "info": "ℹ", "warning": "⚠"}.get(kind, "ℹ")

    toast = ctk.CTkFrame(root, corner_radius=T.RADIUS_SM, fg_color=T.BG_SURFACE_2,
                         border_width=1, border_color=color)
    inner = ctk.CTkFrame(toast, fg_color="transparent")
    inner.pack(padx=14, pady=10)
    ctk.CTkLabel(inner, text=icon, text_color=color, font=T.font(14, "bold")).pack(side="left")
    ctk.CTkLabel(inner, text=message, text_color=T.TEXT_PRIMARY, font=T.FONT_BODY()).pack(
        side="left", padx=(8, 0))

    root.update_idletasks()
    x = root.winfo_width() - toast.winfo_reqwidth() - 26
    y = root.winfo_height() - toast.winfo_reqheight() - 26
    toast.place(x=max(x, 10), y=max(y, 10))
    toast.lift()
    root.after(duration, toast.destroy)


def show_inline_error(parent, error_label, message):
    error_label.configure(text=f"⚠ {message}")


# ============================================================
#  ECG STRIP — animated heartbeat line for dashboard flair
# ============================================================

class ECGStrip(ctk.CTkFrame):
    """A continuously scrolling ECG waveform on a tk.Canvas. Purely decorative,
    reinforces the hospital theme on the dashboard header."""

    def __init__(self, master, width=420, height=70, color=None, speed_ms=30):
        super().__init__(master, fg_color="transparent")
        self.width = width
        self.height = height
        self.color = color or T.ACCENT_RED
        self.speed_ms = speed_ms
        self.offset = 0

        self.canvas = tk.Canvas(self, width=width, height=height,
                                 bg=T.BG_SURFACE, highlightthickness=0)
        self.canvas.pack()
        self._wave = self._build_waveform()
        self._running = True
        self._tick()

    def _build_waveform(self):
        """One repeating heartbeat cycle: flat -> P wave -> QRS spike -> T wave -> flat."""
        pts = []
        cycle = 90
        for x in range(cycle):
            if x < 14:
                y = 0
            elif x < 20:
                y = 6 * ((x - 14) / 6)
            elif x < 26:
                y = 6 * (1 - (x - 20) / 6)
            elif x < 30:
                y = 0
            elif x < 33:
                y = -10 * ((x - 30) / 3)
            elif x < 36:
                y = -10 + 55 * ((x - 33) / 3)
            elif x < 40:
                y = 45 - 60 * ((x - 36) / 4)
            elif x < 44:
                y = -15 + 15 * ((x - 40) / 4)
            elif x < 56:
                y = 0
            elif x < 64:
                y = 10 * ((x - 56) / 8)
            elif x < 72:
                y = 10 * (1 - (x - 64) / 8)
            else:
                y = 0
            pts.append(y)
        return pts

    def _tick(self):
        if not self._running:
            return
        self.canvas.delete("all")
        cycle = len(self._wave)
        mid = self.height / 2
        step = 4
        points = []
        n = self.width // step + 2
        for i in range(n):
            x = i * step
            idx = (i + self.offset) % cycle
            y = mid - self._wave[idx] * 0.9
            points.extend([x, y])
        if len(points) >= 4:
            self.canvas.create_line(*points, fill=self.color, width=2, smooth=True)
        # faint horizontal guideline
        self.canvas.create_line(0, mid, self.width, mid, fill=T.BORDER_SOFT, width=1, dash=(2, 4))
        self.offset = (self.offset + 1) % cycle
        self.after(self.speed_ms, self._tick)

    def stop(self):
        self._running = False


# ============================================================
#  DETAIL DIALOG — read-only multi-line viewer
# ============================================================

class DetailDialog(ctk.CTkToplevel):
    """Read-only scrollable viewer used for 'View History' / 'View Details' actions."""

    def __init__(self, master, title, sections):
        """sections: list of (heading, [line, line, ...]) tuples."""
        super().__init__(master)
        self.title(title)
        self.geometry("560x620")
        self.configure(fg_color=T.BG_APP)
        self.attributes("-topmost", True)
        self.grab_set()

        ctk.CTkLabel(self, text=title, font=T.FONT_H2(), text_color=T.TEXT_PRIMARY).pack(
            anchor="w", padx=24, pady=(22, 14))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24)

        if not sections:
            ctk.CTkLabel(scroll, text="No data available.", font=T.FONT_BODY(),
                         text_color=T.TEXT_MUTED).pack(anchor="w", pady=20)

        for heading, lines in sections:
            ctk.CTkLabel(scroll, text=heading, font=T.FONT_H3(),
                         text_color=T.ACCENT_RED, anchor="w").pack(
                anchor="w", pady=(14, 6))
            card = ctk.CTkFrame(scroll, corner_radius=T.RADIUS_SM, fg_color=T.BG_SURFACE_2,
                                border_width=1, border_color=T.BORDER_SOFT)
            card.pack(fill="x", pady=(0, 4))
            if not lines:
                ctk.CTkLabel(card, text="— none —", font=T.FONT_SMALL(),
                             text_color=T.TEXT_MUTED).pack(anchor="w", padx=14, pady=10)
            for line in lines:
                ctk.CTkLabel(card, text=line, font=T.FONT_BODY(), text_color=T.TEXT_PRIMARY,
                             anchor="w", justify="left", wraplength=480).pack(
                    anchor="w", padx=14, pady=6)

        ctk.CTkButton(self, text="Close", command=self.destroy, height=38,
                      fg_color=T.BG_SURFACE_2, hover_color=T.BORDER,
                      text_color=T.TEXT_PRIMARY, font=T.font(13, "bold")).pack(
            pady=18)
